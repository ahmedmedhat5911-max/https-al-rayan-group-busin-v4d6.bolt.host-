import { Link } from "react-router-dom";
import { useI18n } from "../i18n";
import { Reveal } from "../components/Reveal";

const stats = [
  { key: "about.stats.clients", value: "500+" },
  { key: "about.stats.years", value: "12" },
  { key: "about.stats.listings", value: "180+" },
  { key: "about.stats.langs", value: "2" },
];

const services = [
  {
    key: "s1",
    icon: "M3 21h18M5 21V8l7-5 7 5v13M9 21v-6h6v6",
  },
  {
    key: "s2",
    icon: "M5 17h14l-1.5-6a2 2 0 00-2-1.5h-7a2 2 0 00-2 1.5L5 17zM7.5 17.5a1.5 1.5 0 100 3 1.5 1.5 0 000-3zM16.5 17.5a1.5 1.5 0 100 3 1.5 1.5 0 000-3z",
  },
  {
    key: "s3",
    icon: "M12 2l3 6 6 .9-4.5 4.3 1 6.1L12 17l-5.5 2.3 1-6.1L3 8.9 9 8l3-6z",
  },
];

const testimonials = [
  {
    ar: { name: "خالد عبد الرحمن", role: "رجل أعمال — السعودية", text: "خدمة احترافية من أول لحظة. شقة فاخرة وسيارة بسائق كانت بانتظاري فور وصولي للقاهرة." },
    en: { name: "Khalid A.", role: "Businessman — Saudi Arabia", text: "Professional service from the first moment. A luxury apartment and chauffeured car were waiting for me the moment I landed in Cairo." },
  },
  {
    ar: { name: "Emma Wilson", role: "مديرة تنفيذية — المملكة المتحدة", text: "The team handled everything in perfect English — housing, transport, and even reservations. Truly world-class." },
    en: { name: "Emma Wilson", role: "Executive — UK", text: "The team handled everything in perfect English — housing, transport, and even reservations. Truly world-class." },
  },
  {
    ar: { name: "أحمد منصور", role: "مستثمر — مصر", text: "اشتريت شقة عبر الريان جروب وكانت العملية شفافة وسلسة من البداية للنهاية. فريق موثوق." },
    en: { name: "Ahmed Mansour", role: "Investor — Egypt", text: "I bought an apartment through Al Rayan Group and the process was transparent and smooth end to end. A team you can trust." },
  },
];

export function AboutPage() {
  const { t, lang, pick } = useI18n();

  return (
    <>
      {/* Hero */}
      <section className="relative flex h-[42vh] min-h-[320px] items-end overflow-hidden pt-20">
        <img
          src="https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg"
          alt=""
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0" style={{ background: "linear-gradient(to top, #0a0a0b, rgba(10,10,11,0.7) 60%, rgba(10,10,11,0.4))" }} />
        <div className="container-lux relative z-10 pb-12">
          <Reveal>
            <span className="kicker">{t("about.kicker")}</span>
            <h1 className="mt-3 font-display text-4xl font-bold text-white sm:text-5xl">
              {t("about.title")}
            </h1>
          </Reveal>
        </div>
      </section>

      {/* Story */}
      <section className="section-pad bg-ink-950">
        <div className="container-lux">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <Reveal>
              <span className="kicker">{t("about.kicker")}</span>
              <h2 className="mt-3 font-display text-3xl font-bold text-ink-50 sm:text-4xl">
                {lang === "ar" ? "قصتنا" : "Our Story"}
              </h2>
              <p className="mt-6 text-lg leading-relaxed text-ink-200">{t("about.lead")}</p>
              <p className="mt-4 leading-relaxed text-ink-300">{t("about.p1")}</p>
              <p className="mt-4 leading-relaxed text-ink-300">{t("about.p2")}</p>
            </Reveal>

            <Reveal delay={200}>
              <div className="relative overflow-hidden rounded-2xl">
                <img
                  src="https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg"
                  alt="Al Rayan Group team"
                  className="aspect-[4/3] w-full object-cover"
                  loading="lazy"
                />
                <div className="absolute inset-0 ring-1 ring-inset ring-gold-400/20" />
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="bg-gradient-to-b from-ink-950 to-ink-900/40 py-16">
        <div className="container-lux">
          <div className="grid grid-cols-2 gap-4 sm:gap-6 lg:grid-cols-4">
            {stats.map((s, i) => (
              <Reveal key={s.key} delay={i * 100}>
                <div className="rounded-2xl border border-ink-600/40 bg-ink-900/60 p-8 text-center transition-colors duration-500 hover:border-gold-400/30">
                  <div className="font-display text-5xl font-bold gold-text">{s.value}</div>
                  <div className="mt-3 text-xs font-medium uppercase tracking-wider text-ink-300">
                    {t(s.key)}
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="section-pad bg-ink-950">
        <div className="container-lux">
          <Reveal className="mx-auto max-w-2xl text-center">
            <span className="kicker">{t("about.kicker")}</span>
            <h2 className="mt-3 font-display text-3xl font-bold text-ink-50 sm:text-4xl">
              {t("about.services.title")}
            </h2>
            <div className="divider-gold mt-6" />
          </Reveal>

          <div className="mt-14 grid gap-6 md:grid-cols-3">
            {services.map((s, i) => (
              <Reveal key={s.key} delay={i * 120}>
                <div className="group h-full rounded-2xl border border-ink-600/40 bg-ink-900/60 p-8 transition-all duration-500 ease-luxury hover:border-gold-400/30 hover:-translate-y-1">
                  <div className="grid h-14 w-14 place-items-center rounded-xl bg-gold-400/10 text-gold-300 transition-colors duration-500 group-hover:bg-gold-400 group-hover:text-ink-950">
                    <svg viewBox="0 0 24 24" className="h-7 w-7" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
                      <path d={s.icon} />
                    </svg>
                  </div>
                  <h3 className="mt-5 font-display text-xl font-bold text-ink-50">
                    {t(`about.services.${s.key}.title`)}
                  </h3>
                  <p className="mt-2 leading-relaxed text-ink-300">
                    {t(`about.services.${s.key}.desc`)}
                  </p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="bg-gradient-to-b from-ink-950 to-ink-900/40 py-20">
        <div className="container-lux">
          <Reveal className="mx-auto max-w-2xl text-center">
            <span className="kicker">{t("about.kicker")}</span>
            <h2 className="mt-3 font-display text-3xl font-bold text-ink-50 sm:text-4xl">
              {t("about.testimonials.title")}
            </h2>
            <div className="divider-gold mt-6" />
          </Reveal>

          <div className="mt-14 grid gap-6 md:grid-cols-3">
            {testimonials.map((tm, i) => {
              const data = pick(tm.ar, tm.en);
              return (
                <Reveal key={i} delay={i * 120}>
                  <figure className="h-full rounded-2xl border border-ink-600/40 bg-ink-900/60 p-7">
                    <div className="mb-4 flex gap-1 text-gold-400">
                      {Array.from({ length: 5 }).map((_, k) => (
                        <Star key={k} />
                      ))}
                    </div>
                    <blockquote className="leading-relaxed text-ink-200">"{data.text}"</blockquote>
                    <figcaption className="mt-5 border-t border-ink-600/40 pt-4">
                      <div className="font-semibold text-ink-50">{data.name}</div>
                      <div className="text-xs text-gold-300">{data.role}</div>
                    </figcaption>
                  </figure>
                </Reveal>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-ink-950 py-20">
        <div className="container-lux text-center">
          <Reveal>
            <h2 className="mx-auto max-w-xl font-display text-3xl font-bold text-ink-50">
              {lang === "ar" ? "تعرف علينا أكثر؟" : "Want to know more?"}
            </h2>
            <div className="mt-7 flex flex-wrap justify-center gap-4">
              <Link to="/contact" className="btn-gold">{t("cta.getInTouch")}</Link>
              <Link to="/" className="btn-ghost">{t("nav.home")}</Link>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}

function Star() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4" fill="currentColor">
      <path d="M12 2l3 6 6 .9-4.5 4.3 1 6.1L12 17l-5.5 2.3 1-6.1L3 8.9 9 8l3-6z" />
    </svg>
  );
}
