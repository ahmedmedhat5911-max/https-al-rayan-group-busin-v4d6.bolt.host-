import { useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import { useI18n } from "../i18n";
import { useListings } from "../hooks/useListings";
import { Reveal } from "../components/Reveal";
import { ListingCard } from "../components/ListingCard";
import { ListingModal } from "../components/ListingModal";
import type { Listing, ListingCategory } from "../types";

const validCategories: ListingCategory[] = [
  "apartment_rent",
  "apartment_sale",
  "car_rent",
  "car_sale",
];

type SortKey = "newest" | "priceLow" | "priceHigh";

export function ListingsPage() {
  const { category: param } = useParams();
  const category = validCategories.includes(param as ListingCategory)
    ? (param as ListingCategory)
    : null;

  const { t, lang } = useI18n();
  const { listings, loading, error } = useListings(category);
  const [selected, setSelected] = useState<Listing | null>(null);
  const [region, setRegion] = useState<string>("all");
  const [sort, setSort] = useState<SortKey>("newest");

  const regions = useMemo(() => {
    const set = new Set<string>();
    listings.forEach((l) => l.region && set.add(l.region));
    return Array.from(set);
  }, [listings]);

  const filtered = useMemo(() => {
    let out = [...listings];
    if (region !== "all") out = out.filter((l) => l.region === region);
    if (sort === "priceLow") out.sort((a, b) => (a.price ?? Infinity) - (b.price ?? Infinity));
    else if (sort === "priceHigh") out.sort((a, b) => (b.price ?? -Infinity) - (a.price ?? -Infinity));
    else out.sort((a, b) => (b.sort_order - a.sort_order) || (b.created_at.localeCompare(a.created_at)));
    return out;
  }, [listings, region, sort]);

  const regionLabels: Record<string, { ar: string; en: string }> = {
    new_cairo: { ar: "القاهرة الجديدة", en: "New Cairo" },
    maadi: { ar: "المعادي", en: "Maadi" },
    zamalek: { ar: "زمالك", en: "Zamalek" },
    sheikh_zayed: { ar: "الشيخ زايد", en: "Sheikh Zayed" },
    north_coast: { ar: "الساحل الشمالي", en: "North Coast" },
    cairo: { ar: "القاهرة", en: "Cairo" },
  };

  const heroImg =
    category === "apartment_rent"
      ? "https://images.pexels.com/photos/2724749/pexels-photo-2724749.jpeg"
      : category === "apartment_sale"
      ? "https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg"
      : category === "car_rent"
      ? "https://images.pexels.com/photos/3729464/pexels-photo-3729464.jpeg"
      : "https://images.pexels.com/photos/210019/pexels-photo-210019.jpeg";

  return (
    <>
      {/* Page hero */}
      <section className="relative flex h-[42vh] min-h-[320px] items-end overflow-hidden pt-20">
        <img src={heroImg} alt="" className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink-995 via-ink-950/70 to-ink-950/40" style={{ background: "linear-gradient(to top, #0a0a0b, rgba(10,10,11,0.7) 60%, rgba(10,10,11,0.4))" }} />
        <div className="container-lux relative z-10 pb-12">
          <Reveal>
            <span className="kicker">{t("about.kicker")}</span>
            <h1 className="mt-3 font-display text-4xl font-bold text-white sm:text-5xl">
              {category ? t(`section.${category}.title`) : t("nav.home")}
            </h1>
            {category && (
              <p className="mt-3 max-w-xl text-ink-200">{t(`section.${category}.subtitle`)}</p>
            )}
          </Reveal>
        </div>
      </section>

      {/* Filters + grid */}
      <section className="section-pad bg-ink-950">
        <div className="container-lux">
          {/* Filter bar */}
          <div className="mb-10 flex flex-wrap items-center gap-4 border-b border-ink-600/40 pb-6">
            {regions.length > 0 && (
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold uppercase tracking-wider text-ink-400">
                  {t("filter.region")}
                </span>
                <select
                  value={region}
                  onChange={(e) => setRegion(e.target.value)}
                  className="rounded-lg border border-ink-600/50 bg-ink-900 px-3 py-2 text-sm text-ink-100 focus:border-gold-400/60 focus:outline-none"
                >
                  <option value="all">{t("filter.all")}</option>
                  {regions.map((r) => (
                    <option key={r} value={r}>
                      {lang === "ar" ? regionLabels[r]?.ar ?? r : regionLabels[r]?.en ?? r}
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-ink-400">
                {t("filter.sort")}
              </span>
              <select
                value={sort}
                onChange={(e) => setSort(e.target.value as SortKey)}
                className="rounded-lg border border-ink-600/50 bg-ink-900 px-3 py-2 text-sm text-ink-100 focus:border-gold-400/60 focus:outline-none"
              >
                <option value="newest">{t("filter.sort.newest")}</option>
                <option value="priceLow">{t("filter.sort.priceLow")}</option>
                <option value="priceHigh">{t("filter.sort.priceHigh")}</option>
              </select>
            </div>

            <div className="ms-auto text-sm text-ink-400">
              {filtered.length} {t("filter.results")}
            </div>
          </div>

          {error && (
            <div className="rounded-xl border border-red-500/30 bg-red-500/10 p-4 text-sm text-red-300">
              {t("common.error")} {error}
            </div>
          )}

          {loading ? (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="overflow-hidden rounded-2xl border border-ink-600/40">
                  <div className="aspect-[4/3] skeleton" />
                  <div className="space-y-3 p-5">
                    <div className="h-5 w-3/4 skeleton rounded" />
                    <div className="h-4 w-full skeleton rounded" />
                    <div className="h-9 w-full skeleton rounded-full" />
                  </div>
                </div>
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <div className="py-24 text-center">
              <p className="text-ink-300">{t("filter.noResults")}</p>
            </div>
          ) : (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {filtered.map((l, i) => (
                <Reveal key={l.id} delay={(i % 3) * 80}>
                  <ListingCard listing={l} onOpen={setSelected} />
                </Reveal>
              ))}
            </div>
          )}
        </div>
      </section>

      <ListingModal listing={selected} onClose={() => setSelected(null)} />
    </>
  );
}
