import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "../lib/supabase";
import { useI18n } from "../i18n";
import type { Listing, ListingCategory, ListingInput } from "../types";

const emptyInput: ListingInput = {
  category: "apartment_rent",
  title_ar: "",
  title_en: "",
  desc_ar: "",
  desc_en: "",
  price: null,
  currency: "EGP",
  location_ar: "",
  location_en: "",
  region: "",
  bedrooms: null,
  bathrooms: null,
  area_sqm: null,
  make: "",
  model: "",
  year: null,
  spec_ar: "",
  spec_en: "",
  images: [],
  featured: false,
  available: true,
  sort_order: 0,
};

const categories: ListingCategory[] = ["apartment_rent", "apartment_sale", "car_rent", "car_sale"];

export function AdminPage() {
  const { t, lang } = useI18n();
  const [session, setSession] = useState<boolean | null>(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [authErr, setAuthErr] = useState<string | null>(null);
  const [authLoading, setAuthLoading] = useState(false);

  const [listings, setListings] = useState<Listing[]>([]);
  const [loadingListings, setLoadingListings] = useState(true);
  const [editing, setEditing] = useState<ListingInput & { id?: string } | null>(null);
  const [saving, setSaving] = useState(false);
  const [formErr, setFormErr] = useState<string | null>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(!!data.session);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => {
      setSession(!!s);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!session) return;
    loadListings();
  }, [session]);

  async function loadListings() {
    setLoadingListings(true);
    const { data, error } = await supabase
      .from("listings")
      .select("*")
      .order("sort_order", { ascending: false })
      .order("created_at", { ascending: false });
    if (!error && data) setListings(data as Listing[]);
    setLoadingListings(false);
  }

  async function signIn(e: React.FormEvent) {
    e.preventDefault();
    setAuthErr(null);
    setAuthLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setAuthLoading(false);
    if (error) setAuthErr(t("admin.authError"));
  }

  async function signOut() {
    await supabase.auth.signOut();
  }

  async function saveListing(e: React.FormEvent) {
    e.preventDefault();
    if (!editing) return;
    if (!editing.title_ar.trim() || !editing.title_en.trim()) {
      setFormErr(lang === "ar" ? "العنوان بالعربي والإنجليزي مطلوب" : "Arabic and English titles are required");
      return;
    }
    setFormErr(null);
    setSaving(true);

    const payload: ListingInput = {
      ...editing,
      images: editing.images.filter(Boolean),
      price: editing.price === null ? null : Number(editing.price),
      bedrooms: editing.bedrooms === null ? null : Number(editing.bedrooms),
      bathrooms: editing.bathrooms === null ? null : Number(editing.bathrooms),
      area_sqm: editing.area_sqm === null ? null : Number(editing.area_sqm),
      year: editing.year === null ? null : Number(editing.year),
      sort_order: Number(editing.sort_order) || 0,
    };

    let err;
    if (editing.id) {
      ({ error: err } = await supabase.from("listings").update(payload).eq("id", editing.id));
    } else {
      ({ error: err } = await supabase.from("listings").insert(payload));
    }
    setSaving(false);
    if (err) {
      setFormErr(err.message);
      return;
    }
    setEditing(null);
    await loadListings();
  }

  async function deleteListing(id: string) {
    if (!confirm(t("admin.confirmDelete"))) return;
    const { error } = await supabase.from("listings").delete().eq("id", id);
    if (!error) await loadListings();
  }

  if (session === null) {
    return (
      <div className="grid min-h-screen place-items-center bg-ink-950 pt-20 text-ink-300">
        {t("admin.loading")}
      </div>
    );
  }

  if (!session) {
    return (
      <div className="grid min-h-screen place-items-center bg-ink-950 px-4 pt-20">
        <form onSubmit={signIn} className="w-full max-w-md rounded-2xl border border-ink-600/40 bg-ink-900/60 p-8">
          <h1 className="font-display text-2xl font-bold text-ink-50">{t("admin.login")}</h1>
          <p className="mt-1 text-sm text-ink-400">{t("admin.title")}</p>

          <div className="mt-6 space-y-4">
            <div>
              <label className="label-lux" htmlFor="email">{t("admin.email")}</label>
              <input
                id="email"
                type="email"
                required
                className="input-lux"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                dir="ltr"
              />
            </div>
            <div>
              <label className="label-lux" htmlFor="pw">{t("admin.password")}</label>
              <input
                id="pw"
                type="password"
                required
                className="input-lux"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                dir="ltr"
              />
            </div>
          </div>

          {authErr && <p className="mt-4 rounded-lg bg-red-500/10 p-3 text-sm text-red-300">{authErr}</p>}

          <button type="submit" disabled={authLoading} className="btn-gold mt-6 w-full">
            {authLoading ? t("admin.loading") : t("admin.signIn")}
          </button>

          <Link to="/" className="mt-4 block text-center text-xs text-ink-400 hover:text-gold-300">
            {t("admin.backHome")}
          </Link>
        </form>
      </div>
    );
  }

  // Authenticated view
  return (
    <div className="min-h-screen bg-ink-950 pt-24">
      <div className="container-lux pb-20">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="font-display text-3xl font-bold text-ink-50">{t("admin.title")}</h1>
            <p className="mt-1 text-sm text-ink-400">{listings.length} {t("admin.listings")}</p>
          </div>
          <div className="flex gap-3">
            <button onClick={() => setEditing({ ...emptyInput })} className="btn-gold !py-2.5 !text-xs">
              + {t("admin.add")}
            </button>
            <button onClick={signOut} className="btn-ghost !py-2.5 !text-xs">
              {t("admin.signOut")}
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="mt-8 overflow-hidden rounded-2xl border border-ink-600/40 bg-ink-900/60">
          {loadingListings ? (
            <div className="p-10 text-center text-ink-400">{t("admin.loading")}</div>
          ) : listings.length === 0 ? (
            <div className="p-10 text-center text-ink-400">{t("admin.empty")}</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-start text-sm">
                <thead className="border-b border-ink-600/40 text-xs uppercase tracking-wider text-ink-400">
                  <tr>
                    <th className="p-4 text-start">{lang === "ar" ? "العنوان" : "Title"}</th>
                    <th className="p-4 text-start">{lang === "ar" ? "القسم" : "Category"}</th>
                    <th className="p-4 text-start">{lang === "ar" ? "السعر" : "Price"}</th>
                    <th className="p-4 text-start">{lang === "ar" ? "مميز" : "Featured"}</th>
                    <th className="p-4 text-end">{lang === "ar" ? "إجراءات" : "Actions"}</th>
                  </tr>
                </thead>
                <tbody>
                  {listings.map((l) => (
                    <tr key={l.id} className="border-b border-ink-600/30 last:border-0">
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          {l.images[0] && (
                            <img src={l.images[0]} alt="" className="h-10 w-14 rounded object-cover" />
                          )}
                          <span className="font-medium text-ink-100">{lang === "ar" ? l.title_ar : l.title_en}</span>
                        </div>
                      </td>
                      <td className="p-4 text-ink-300">{t(`section.${l.category}.title`)}</td>
                      <td className="p-4 text-ink-300">
                        {l.price ? new Intl.NumberFormat("en-US").format(l.price) : t("card.priceOnRequest")}
                      </td>
                      <td className="p-4">
                        {l.featured ? (
                          <span className="rounded-full bg-gold-400/20 px-2.5 py-0.5 text-xs font-semibold text-gold-300">★</span>
                        ) : (
                          <span className="text-ink-500">—</span>
                        )}
                      </td>
                      <td className="p-4">
                        <div className="flex justify-end gap-2">
                          <button
                            onClick={() => setEditing({ ...l })}
                            className="rounded-lg border border-ink-600/40 px-3 py-1.5 text-xs text-ink-100 hover:border-gold-400/50 hover:text-gold-300"
                          >
                            {t("admin.edit")}
                          </button>
                          <button
                            onClick={() => deleteListing(l.id)}
                            className="rounded-lg border border-red-500/30 px-3 py-1.5 text-xs text-red-300 hover:bg-red-500/10"
                          >
                            {t("admin.delete")}
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {editing && (
        <ListingForm
          value={editing}
          onChange={setEditing}
          onClose={() => setEditing(null)}
          onSubmit={saveListing}
          saving={saving}
          error={formErr}
        />
      )}
    </div>
  );
}

function ListingForm({
  value,
  onChange,
  onClose,
  onSubmit,
  saving,
  error,
}: {
  value: ListingInput & { id?: string };
  onChange: (v: ListingInput & { id?: string }) => void;
  onClose: () => void;
  onSubmit: (e: React.FormEvent) => void;
  saving: boolean;
  error: string | null;
}) {
  const { t, lang } = useI18n();
  const set = (patch: Partial<ListingInput>) => onChange({ ...value, ...patch });
  const isCar = value.category.startsWith("car_");

  return (
    <div className="fixed inset-0 z-[70] flex items-start justify-center overflow-y-auto bg-ink-950/85 p-4 backdrop-blur-md pt-10">
      <form
        onSubmit={onSubmit}
        className="my-8 w-full max-w-3xl rounded-2xl border border-ink-600/40 bg-ink-900 p-6 sm:p-8"
      >
        <div className="flex items-center justify-between">
          <h2 className="font-display text-2xl font-bold text-ink-50">
            {value.id ? t("admin.edit") : t("admin.add")}
          </h2>
          <button type="button" onClick={onClose} className="text-ink-400 hover:text-gold-300" aria-label={t("cta.close")}>
            <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M18 6L6 18M6 6l12 12" />
            </svg>
          </button>
        </div>

        {error && <p className="mt-4 rounded-lg bg-red-500/10 p-3 text-sm text-red-300">{error}</p>}

        <div className="mt-6 grid gap-5 sm:grid-cols-2">
          <Field label={lang === "ar" ? "القسم" : "Category"} full>
            <select className="input-lux" value={value.category} onChange={(e) => set({ category: e.target.value as ListingCategory })}>
              {categories.map((c) => (
                <option key={c} value={c}>{t(`section.${c}.title`)}</option>
              ))}
            </select>
          </Field>

          <Field label={lang === "ar" ? "العنوان (عربي)" : "Title (Arabic)"}>
            <input className="input-lux" value={value.title_ar} onChange={(e) => set({ title_ar: e.target.value })} dir="rtl" required />
          </Field>
          <Field label={lang === "ar" ? "العنوان (إنجليزي)" : "Title (English)"}>
            <input className="input-lux" value={value.title_en} onChange={(e) => set({ title_en: e.target.value })} dir="ltr" required />
          </Field>

          <Field label={lang === "ar" ? "الوصف (عربي)" : "Description (Arabic)"}>
            <textarea rows={2} className="input-lux resize-none" value={value.desc_ar ?? ""} onChange={(e) => set({ desc_ar: e.target.value })} dir="rtl" />
          </Field>
          <Field label={lang === "ar" ? "الوصف (إنجليزي)" : "Description (English)"}>
            <textarea rows={2} className="input-lux resize-none" value={value.desc_en ?? ""} onChange={(e) => set({ desc_en: e.target.value })} dir="ltr" />
          </Field>

          <Field label={lang === "ar" ? "الموقع (عربي)" : "Location (Arabic)"}>
            <input className="input-lux" value={value.location_ar ?? ""} onChange={(e) => set({ location_ar: e.target.value })} dir="rtl" />
          </Field>
          <Field label={lang === "ar" ? "الموقع (إنجليزي)" : "Location (English)"}>
            <input className="input-lux" value={value.location_en ?? ""} onChange={(e) => set({ location_en: e.target.value })} dir="ltr" />
          </Field>

          <Field label={lang === "ar" ? "المنطقة (مفتاح)" : "Region (key)"}>
            <input className="input-lux" value={value.region ?? ""} onChange={(e) => set({ region: e.target.value })} placeholder="new_cairo" dir="ltr" />
          </Field>
          <Field label={lang === "ar" ? "السعر (فارغ = عند الطلب)" : "Price (blank = on request)"}>
            <input type="number" className="input-lux" value={value.price ?? ""} onChange={(e) => set({ price: e.target.value === "" ? null : Number(e.target.value) })} dir="ltr" />
          </Field>

          {!isCar && (
            <>
              <Field label={lang === "ar" ? "غرف النوم" : "Bedrooms"}>
                <input type="number" className="input-lux" value={value.bedrooms ?? ""} onChange={(e) => set({ bedrooms: e.target.value === "" ? null : Number(e.target.value) })} dir="ltr" />
              </Field>
              <Field label={lang === "ar" ? "الحمامات" : "Bathrooms"}>
                <input type="number" className="input-lux" value={value.bathrooms ?? ""} onChange={(e) => set({ bathrooms: e.target.value === "" ? null : Number(e.target.value) })} dir="ltr" />
              </Field>
              <Field label={lang === "ar" ? "المساحة (م²)" : "Area (sqm)"}>
                <input type="number" className="input-lux" value={value.area_sqm ?? ""} onChange={(e) => set({ area_sqm: e.target.value === "" ? null : Number(e.target.value) })} dir="ltr" />
              </Field>
            </>
          )}

          {isCar && (
            <>
              <Field label={lang === "ar" ? "الماركة" : "Make"}>
                <input className="input-lux" value={value.make ?? ""} onChange={(e) => set({ make: e.target.value })} dir="ltr" />
              </Field>
              <Field label={lang === "ar" ? "الموديل" : "Model"}>
                <input className="input-lux" value={value.model ?? ""} onChange={(e) => set({ model: e.target.value })} dir="ltr" />
              </Field>
              <Field label={lang === "ar" ? "السنة" : "Year"}>
                <input type="number" className="input-lux" value={value.year ?? ""} onChange={(e) => set({ year: e.target.value === "" ? null : Number(e.target.value) })} dir="ltr" />
              </Field>
              <Field label={lang === "ar" ? "المواصفات (عربي)" : "Spec (Arabic)"}>
                <input className="input-lux" value={value.spec_ar ?? ""} onChange={(e) => set({ spec_ar: e.target.value })} dir="rtl" />
              </Field>
              <Field label={lang === "ar" ? "المواصفات (إنجليزي)" : "Spec (English)"}>
                <input className="input-lux" value={value.spec_en ?? ""} onChange={(e) => set({ spec_en: e.target.value })} dir="ltr" />
              </Field>
            </>
          )}

          <Field label={lang === "ar" ? "روابط الصور (سطر لكل رابط)" : "Image URLs (one per line)"} full>
            <textarea
              rows={4}
              className="input-lux resize-none font-mono text-xs"
              value={value.images.join("\n")}
              onChange={(e) => set({ images: e.target.value.split("\n") })}
              dir="ltr"
              placeholder="https://images.pexels.com/photos/..."
            />
          </Field>

          <Field label={lang === "ar" ? "ترتيب" : "Sort order"}>
            <input type="number" className="input-lux" value={value.sort_order} onChange={(e) => set({ sort_order: Number(e.target.value) })} dir="ltr" />
          </Field>

          <div className="flex items-end gap-6 pb-2">
            <label className="flex items-center gap-2 text-sm text-ink-200">
              <input type="checkbox" checked={value.featured} onChange={(e) => set({ featured: e.target.checked })} className="h-4 w-4 accent-gold-400" />
              {lang === "ar" ? "مميز" : "Featured"}
            </label>
            <label className="flex items-center gap-2 text-sm text-ink-200">
              <input type="checkbox" checked={value.available} onChange={(e) => set({ available: e.target.checked })} className="h-4 w-4 accent-gold-400" />
              {lang === "ar" ? "متاح" : "Available"}
            </label>
          </div>
        </div>

        <div className="mt-7 flex justify-end gap-3">
          <button type="button" onClick={onClose} className="btn-ghost !py-2.5 !text-xs">
            {t("admin.cancel")}
          </button>
          <button type="submit" disabled={saving} className="btn-gold !py-2.5 !text-xs">
            {saving ? t("admin.loading") : t("admin.save")}
          </button>
        </div>
      </form>
    </div>
  );
}

function Field({ label, children, full }: { label: string; children: React.ReactNode; full?: boolean }) {
  return (
    <div className={full ? "sm:col-span-2" : ""}>
      <label className="label-lux">{label}</label>
      {children}
    </div>
  );
}
