import { useState } from "react";
import { useI18n } from "../i18n";
import { Reveal } from "../components/Reveal";
import { WhatsAppIcon, buildContactMessage } from "../components/whatsapp";
import { COMPANY, whatsappLink } from "../lib/company";

export function ContactPage() {
  const { t, lang } = useI18n();
  const [form, setForm] = useState({ name: "", phone: "", service: "apartment_rent", message: "" });
  const [errors, setErrors] = useState<{ name?: string; phone?: string }>({});
  const [href, setHref] = useState<string | null>(null);

  const validate = () => {
    const e: typeof errors = {};
    if (!form.name.trim()) e.name = t("contact.form.error.name");
    if (!/^[0-9+\s-]{8,}$/.test(form.phone.trim())) e.phone = t("contact.form.error.phone");
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const onSubmit = (ev: React.FormEvent) => {
    ev.preventDefault();
    if (!validate()) return;
    const url = whatsappLink(
      buildContactMessage({
        name: form.name.trim(),
        phone: form.phone.trim(),
        service: form.service,
        message: form.message.trim(),
        lang,
      })
    );
    setHref(url);
    window.open(url, "_blank", "noopener,noreferrer");
  };

  return (
    <>
      {/* Hero */}
      <section className="relative flex h-[36vh] min-h-[280px] items-end overflow-hidden pt-20">
        <img
          src="https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg"
          alt=""
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0" style={{ background: "linear-gradient(to top, #0a0a0b, rgba(10,10,11,0.7) 60%, rgba(10,10,11,0.4))" }} />
        <div className="container-lux relative z-10 pb-12">
          <Reveal>
            <span className="kicker">{t("about.kicker")}</span>
            <h1 className="mt-3 font-display text-4xl font-bold text-white sm:text-5xl">
              {t("contact.title")}
            </h1>
            <p className="mt-3 max-w-xl text-ink-200">{t("contact.subtitle")}</p>
          </Reveal>
        </div>
      </section>

      <section className="section-pad bg-ink-950">
        <div className="container-lux">
          <div className="grid gap-10 lg:grid-cols-5">
            {/* Form */}
            <Reveal className="lg:col-span-3">
              <form
                onSubmit={onSubmit}
                className="rounded-2xl border border-ink-600/40 bg-ink-900/60 p-6 sm:p-8"
              >
                <h2 className="font-display text-2xl font-bold text-ink-50">
                  {t("contact.title")}
                </h2>

                <div className="mt-6 grid gap-5 sm:grid-cols-2">
                  <div className="sm:col-span-1">
                    <label className="label-lux" htmlFor="name">
                      {t("contact.form.name")}
                    </label>
                    <input
                      id="name"
                      className="input-lux"
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      placeholder={t("contact.form.placeholder.name")}
                      dir="auto"
                    />
                    {errors.name && <p className="mt-1.5 text-xs text-red-400">{errors.name}</p>}
                  </div>

                  <div className="sm:col-span-1">
                    <label className="label-lux" htmlFor="phone">
                      {t("contact.form.phone")}
                    </label>
                    <input
                      id="phone"
                      className="input-lux"
                      value={form.phone}
                      onChange={(e) => setForm({ ...form, phone: e.target.value })}
                      placeholder={t("contact.form.placeholder.phone")}
                      dir="ltr"
                      inputMode="tel"
                    />
                    {errors.phone && <p className="mt-1.5 text-xs text-red-400">{errors.phone}</p>}
                  </div>

                  <div className="sm:col-span-2">
                    <label className="label-lux" htmlFor="service">
                      {t("contact.form.service")}
                    </label>
                    <select
                      id="service"
                      className="input-lux"
                      value={form.service}
                      onChange={(e) => setForm({ ...form, service: e.target.value })}
                    >
                      <option value="apartment_rent">{t("contact.form.service.apartment_rent")}</option>
                      <option value="apartment_sale">{t("contact.form.service.apartment_sale")}</option>
                      <option value="car_rent">{t("contact.form.service.car_rent")}</option>
                      <option value="car_sale">{t("contact.form.service.car_sale")}</option>
                      <option value="other">{t("contact.form.service.other")}</option>
                    </select>
                  </div>

                  <div className="sm:col-span-2">
                    <label className="label-lux" htmlFor="message">
                      {t("contact.form.message")}
                    </label>
                    <textarea
                      id="message"
                      rows={4}
                      className="input-lux resize-none"
                      value={form.message}
                      onChange={(e) => setForm({ ...form, message: e.target.value })}
                      placeholder={t("contact.form.placeholder.message")}
                      dir="auto"
                    />
                  </div>
                </div>

                <button type="submit" className="btn-gold mt-6 w-full sm:w-auto">
                  <WhatsAppIcon className="h-5 w-5" /> {t("contact.form.submit")}
                </button>
                {href && (
                  <p className="mt-3 text-xs text-ink-400">
                    {lang === "ar"
                      ? "تم فتح واتساب برسالة جاهزة. إذا لم يفتح، اضغط هنا:"
                      : "WhatsApp opened with a pre-filled message. If it didn't, click here:"}{" "}
                    <a href={href} target="_blank" rel="noopener noreferrer" className="text-gold-300 underline">
                      WhatsApp
                    </a>
                  </p>
                )}
              </form>
            </Reveal>

            {/* Info */}
            <Reveal delay={150} className="lg:col-span-2">
              <div className="rounded-2xl border border-ink-600/40 bg-ink-900/60 p-6 sm:p-8">
                <h2 className="font-display text-xl font-bold text-ink-50">
                  {t("contact.info.title")}
                </h2>
                <ul className="mt-6 space-y-5">
                  <InfoRow icon={<WhatsAppIcon className="h-5 w-5" />} label={t("contact.info.whatsapp")} value={COMPANY.phoneDisplay} href={`https://wa.me/${COMPANY.whatsapp}`} />
                  <InfoRow icon={<PhoneIcon />} label={t("contact.info.phone")} value={COMPANY.phoneDisplay} href={`tel:${COMPANY.phoneIntl}`} />
                  <InfoRow icon={<MailIcon />} label={t("contact.info.email")} value={COMPANY.email} href={`mailto:${COMPANY.email}`} />
                  <InfoRow icon={<PinIcon />} label={t("contact.info.address")} value={lang === "ar" ? COMPANY.address_ar : COMPANY.address_en} />
                  <InfoRow icon={<ClockIcon />} label={t("contact.info.hours")} value={t("contact.info.hoursValue")} />
                </ul>
              </div>
            </Reveal>
          </div>
        </div>
      </section>
    </>
  );
}

function InfoRow({
  icon,
  label,
  value,
  href,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  href?: string;
}) {
  const content = (
    <>
      <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-gold-400/10 text-gold-300">
        {icon}
      </span>
      <span className="block">
        <span className="block text-xs font-semibold uppercase tracking-wider text-ink-400">{label}</span>
        <span className="mt-0.5 block text-sm text-ink-100" dir="auto">{value}</span>
      </span>
    </>
  );
  return (
    <li>
      {href ? (
        <a href={href} target="_blank" rel="noopener noreferrer" className="flex items-start gap-4 transition-colors hover:text-gold-300">
          {content}
        </a>
      ) : (
        <div className="flex items-start gap-4">{content}</div>
      )}
    </li>
  );
}

function PhoneIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.7">
      <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72c.13.96.36 1.9.7 2.81a2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.9.34 1.85.57 2.81.7A2 2 0 0122 16.92z" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
function MailIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.7">
      <rect x="2" y="4" width="20" height="16" rx="2" />
      <path d="M22 7l-10 6L2 7" />
    </svg>
  );
}
function PinIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.7">
      <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z" />
      <circle cx="12" cy="10" r="3" />
    </svg>
  );
}
function ClockIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.7">
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3 2" strokeLinecap="round" />
    </svg>
  );
}
