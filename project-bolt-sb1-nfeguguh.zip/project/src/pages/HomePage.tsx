import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { useI18n } from "../i18n";
import { useFeaturedListings } from "../hooks/useListings";
import { Reveal } from "../components/Reveal";
import { ListingCard } from "../components/ListingCard";
import { ListingModal } from "../components/ListingModal";
import type { Listing, ListingCategory } from "../types";

const heroImages = [
  "https://images.pexels.com/photos/3225531/pexels-photo-3225531.jpeg",
  "https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg",
  "https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg",
];

const services: { key: ListingCategory; img: string }[] = [
  { key: "apartment_rent", img: "https://images.pexels.com/photos/2724749/pexels-photo-2724749.jpeg" },
  { key: "apartment_sale", img: "https://images.pexels.com/photos/1080721/pexels-photo-1080721.jpeg" },
  { key: "car_rent", img: "https://images.pexels.com/photos/3729464/pexels-photo-3729464.jpeg" },
  { key: "car_sale", img: "https://images.pexels.com/photos/210019/pexels-photo-210019.jpeg" },
];

const stats = [
  { key: "about.stats.clients", value: "500+" },
  { key: "about.stats.years", value: "12" },
  { key: "about.stats.listings", value: "180+" },
  { key: "about.stats.langs", value: "2" },
];

export function HomePage() {
  const { t, lang } = useI18n();
  const { listings } = useFeaturedListings();
  const [selected, setSelected] = useState<Listing | null>(null);
  const [heroIdx, setHeroIdx] = useState(0);

  useMemo(() => {
    const id = setInterval(() => setHeroIdx((p) => (p + 1) % heroImages.length), 6000);
    return () => clearInterval(id);
  }, []);

  return (
    <>
      {/* HERO */}
      <section className="relative flex min-h-[100svh] items-center overflow-hidden">
        {heroImages.map((src, i) => (
          <div
            key={src}
            className={`absolute inset-0 transition-opacity duration-[1800ms] ease-luxury ${
              i === heroIdx ? "opacity-100" : "opacity-0"
            }`}
          >
            <img
              src={src}
              alt=""
              className="h-full w-full object-cover animate-slow-zoom"
              loading={i === 0 ? "eager" : "lazy"}
            />
          </div>
        ))}
        <div className="absolute inset-0 bg-gradient-to-b from-ink-950/85 via-ink-950/55 to-ink-950" />
        <div className="absolute inset-0 bg-gradient-to-r from-ink-950/80 via-transparent to-ink-950/40" />

        <div className="container-lux relative z-10 pt-24">
          <div className="max-w-2xl">
            <Reveal>
              <span className="inline-flex items-center gap-2 rounded-full border border-gold-400/30 bg-gold-400/5 px-4 py-1.5 text-xs font-semibold tracking-wider text-gold-300">
                <span className="h-1.5 w-1.5 rounded-full bg-gold-400" /> {t("hero.badge")}
              </span>
            </Reveal>
            <Reveal delay={120}>
              <h1 className="mt-6 font-display text-4xl font-bold leading-tight text-white text-balance sm:text-5xl lg:text-6xl">
                {t("hero.title")}
              </h1>
            </Reveal>
            <Reveal delay={240}>
              <p className="mt-6 max-w-xl text-lg leading-relaxed text-ink-200">
                {t("hero.subtitle")}
              </p>
            </Reveal>
            <Reveal delay={360}>
              <div className="mt-9 flex flex-wrap gap-4">
                <Link to="/listings/apartment_rent" className="btn-gold">
                  {t("hero.cta1")}
                </Link>
                <Link to="/listings/car_rent" className="btn-outline-gold">
                  {t("hero.cta2")}
                </Link>
              </div>
            </Reveal>
          </div>
        </div>

        {/* hero dots */}
        <div className="absolute bottom-8 start-1/2 z-10 flex -translate-x-1/2 gap-2 rtl:translate-x-1/2">
          {heroImages.map((_, i) => (
            <button
              key={i}
              onClick={() => setHeroIdx(i)}
              className={`h-1.5 rounded-full transition-all duration-500 ${
                i === heroIdx ? "w-8 bg-gold-400" : "w-1.5 bg-white/40"
              }`}
              aria-label={`Slide ${i + 1}`}
            />
          ))}
        </div>
      </section>

      {/* SERVICES */}
      <section className="section-pad bg-ink-950">
        <div className="container-lux">
          <Reveal className="mx-auto max-w-2xl text-center">
            <span className="kicker">{t("about.kicker")}</span>
            <h2 className="mt-3 font-display text-3xl font-bold text-ink-50 sm:text-4xl">
              {t("cta.explore")}
            </h2>
            <div className="divider-gold mt-6" />
          </Reveal>

          <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {services.map((s, i) => (
              <Reveal key={s.key} delay={i * 100}>
                <Link
                  to={`/listings/${s.key}`}
                  className="group relative block aspect-[3/4] overflow-hidden rounded-2xl"
                >
                  <img
                    src={s.img}
                    alt={t(`section.${s.key}.title`)}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 ease-luxury group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/30 to-transparent transition-colors duration-500 group-hover:from-ink-950/90" />
                  <div className="absolute inset-x-0 bottom-0 p-5">
                    <h3 className="font-display text-xl font-bold text-white">
                      {t(`section.${s.key}.title`)}
                    </h3>
                    <p className="mt-1.5 line-clamp-2 text-xs leading-relaxed text-ink-200">
                      {t(`section.${s.key}.subtitle`)}
                    </p>
                    <span className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-gold-300 transition-all duration-300 group-hover:gap-2.5">
                      {t("cta.viewAll")} <ArrowIcon />
                    </span>
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURED LISTINGS */}
      <section className="section-pad bg-gradient-to-b from-ink-950 to-ink-900/40">
        <div className="container-lux">
          <Reveal className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <span className="kicker">{t("about.kicker")}</span>
              <h2 className="mt-3 font-display text-3xl font-bold text-ink-50 sm:text-4xl">
                {lang === "ar" ? "عناصر مختارة" : "Featured Selections"}
              </h2>
            </div>
            <Link to="/listings/apartment_rent" className="btn-ghost !py-2.5 !text-xs">
              {t("cta.viewAll")} <ArrowIcon />
            </Link>
          </Reveal>

          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {listings.slice(0, 6).map((l, i) => (
              <Reveal key={l.id} delay={(i % 3) * 100}>
                <ListingCard listing={l} onOpen={setSelected} />
              </Reveal>
            ))}
            {listings.length === 0 && (
              <div className="col-span-full py-20 text-center text-ink-400">
                {t("common.loading")}
              </div>
            )}
          </div>
        </div>
      </section>

      {/* ABOUT PREVIEW + STATS */}
      <section className="section-pad bg-ink-950">
        <div className="container-lux">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <Reveal>
              <span className="kicker">{t("about.title")}</span>
              <h2 className="mt-3 font-display text-3xl font-bold text-ink-50 sm:text-4xl">
                {t("about.kicker")}
              </h2>
              <p className="mt-6 text-lg leading-relaxed text-ink-200">{t("about.lead")}</p>
              <p className="mt-4 leading-relaxed text-ink-300">{t("about.p1")}</p>
              <div className="mt-8">
                <Link to="/about" className="btn-outline-gold !py-2.5 !text-xs">
                  {t("nav.about")} <ArrowIcon />
                </Link>
              </div>
            </Reveal>

            <Reveal delay={200}>
              <div className="grid grid-cols-2 gap-4">
                {stats.map((s) => (
                  <div
                    key={s.key}
                    className="rounded-2xl border border-ink-600/40 bg-ink-900/60 p-6 text-center transition-colors duration-500 hover:border-gold-400/30"
                  >
                    <div className="font-display text-4xl font-bold gold-text">{s.value}</div>
                    <div className="mt-2 text-xs font-medium uppercase tracking-wider text-ink-300">
                      {t(s.key)}
                    </div>
                  </div>
                ))}
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="relative overflow-hidden py-24">
        <img
          src="https://images.pexels.com/photos/302769/pexels-photo-302769.jpeg"
          alt=""
          className="absolute inset-0 h-full w-full object-cover"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-ink-950/85" />
        <div className="container-lux relative z-10 text-center">
          <Reveal>
            <h2 className="mx-auto max-w-2xl font-display text-3xl font-bold text-white text-balance sm:text-4xl">
              {lang === "ar"
                ? "هل أنت مستعد لتجربة أعمال بلا قيود؟"
                : "Ready for a seamless business experience?"}
            </h2>
            <p className="mx-auto mt-5 max-w-xl text-ink-200">
              {lang === "ar"
                ? "تواصل مع فريقنا اليوم ودعنا نتولّى التفاصيل بينما تركّز أنت على ما يهم."
                : "Reach out to our team today and let us handle the details while you focus on what matters."}
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-4">
              <Link to="/contact" className="btn-gold">{t("cta.getInTouch")}</Link>
              <Link to="/about" className="btn-outline-gold">{t("nav.about")}</Link>
            </div>
          </Reveal>
        </div>
      </section>

      <ListingModal listing={selected} onClose={() => setSelected(null)} />
    </>
  );
}

function ArrowIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M5 12h14M13 6l6 6-6 6" />
    </svg>
  );
}
