export type ListingCategory =
  | "apartment_rent"
  | "apartment_sale"
  | "car_rent"
  | "car_sale";

export interface Listing {
  id: string;
  category: ListingCategory;
  title_ar: string;
  title_en: string;
  desc_ar: string | null;
  desc_en: string | null;
  price: number | null;
  currency: string;
  location_ar: string | null;
  location_en: string | null;
  region: string | null;
  bedrooms: number | null;
  bathrooms: number | null;
  area_sqm: number | null;
  make: string | null;
  model: string | null;
  year: number | null;
  spec_ar: string | null;
  spec_en: string | null;
  images: string[];
  featured: boolean;
  available: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

export type ListingInput = Omit<Listing, "id" | "created_at" | "updated_at"> & {
  id?: string;
};
