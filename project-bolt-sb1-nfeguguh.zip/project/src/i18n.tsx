import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type Lang = "ar" | "en";

interface I18nContextValue {
  lang: Lang;
  dir: "rtl" | "ltr";
  setLang: (l: Lang) => void;
  toggle: () => void;
  t: (key: string) => string;
  /** pick ar or en value from a bilingual object/record */
  pick: <T>(ar: T, en: T) => T;
}

const dict: Record<Lang, Record<string, string>> = {
  ar: {
    "nav.home": "الرئيسية",
    "nav.apartment_rent": "شقق للإيجار",
    "nav.apartment_sale": "شقق للبيع",
    "nav.car_rent": "عربيات للإيجار",
    "nav.car_sale": "عربيات للبيع",
    "nav.about": "من نحن",
    "nav.contact": "تواصل معنا",
    "nav.admin": "لوحة التحكم",
    "cta.inquire": "استفسر عبر واتساب",
    "cta.contact": "تواصل معنا",
    "cta.viewAll": "عرض الكل",
    "cta.details": "التفاصيل",
    "cta.close": "إغلاق",
    "cta.explore": "اكتشف خدماتنا",
    "cta.getInTouch": "ابدأ الآن",
    "hero.badge": "خدمات رجال الأعمال الأولي",
    "hero.title": "رفيقك في عالم الأعمال بمصر",
    "hero.subtitle":
      "نوفّر لرجال الأعمال المصريين والأجانب سكنًا فاخرًا ومواصلات راقية وخدمات مصاحبة متكاملة بمعايير عالمية.",
    "hero.cta1": "تصفّح العقارات",
    "hero.cta2": "تأجير السيارات",
    "section.apartment_rent.title": "شقق للإيجار",
    "section.apartment_rent.subtitle": "شقق مفروشة راقية في أرقى المناطق لراحة رجل الأعمال",
    "section.apartment_sale.title": "شقق للبيع",
    "section.apartment_sale.subtitle": "فرص تمليك مختارة بعناية في أرقى الكمباوندات",
    "section.car_rent.title": "سيارات للإيجار",
    "section.car_rent.subtitle": "أسطول فاخر مع سائقين محترفين لكل مناسباتك",
    "section.car_sale.title": "سيارات للبيع",
    "section.car_sale.subtitle": "سيارات بحالة الوكالة وضمان معتمد",
    "filter.all": "الكل",
    "filter.region": "المنطقة",
    "filter.sort": "الترتيب",
    "filter.sort.newest": "الأحدث",
    "filter.sort.priceLow": "السعر: الأقل",
    "filter.sort.priceHigh": "السعر: الأعلى",
    "filter.results": "نتيجة",
    "filter.noResults": "لا توجد عناصر مطابقة حالياً.",
    "card.bedrooms": "غرف",
    "card.bathrooms": "حمامات",
    "card.area": "م²",
    "card.year": "موديل",
    "card.location": "الموقع",
    "card.priceOnRequest": "السعر عند الطلب",
    "card.perMonth": "/ شهرياً",
    "card.perDay": "/ يومياً",
    "card.unavailable": "غير متاح",
    "card.available": "متاح",
    "about.title": "من نحن",
    "about.kicker": "الريان جروب",
    "about.lead":
      "الريان جروب شركة متخصصة في خدمات رجال الأعمال الشاملة للعملاء المصريين والأجانب، نجمع بين الخبرة المحلية والمعايير العالمية لنوفّر تجربة سلسة وموثوقة.",
    "about.p1":
      "بدأنا برؤية بسيطة: أن يكون رجل الأعمال الضيف أو المقيم في مصر قادراً على التركيز على عمله بينما نتولّى نحن تأمين سكنه ومواصلاته وكل ما يحتاجه من خدمات مصاحبة.",
    "about.p2":
      "نتعامل باللغتين العربية والإنجليزية، ونهتم بأدق التفاصيل لنضمن لعملائنا راحة وخصوصية ومصداقية على أعلى مستوى.",
    "about.services.title": "نطاق خدماتنا",
    "about.services.s1.title": "تأمين السكن",
    "about.services.s1.desc": "إيجار وتمليك الشقق الفاخرة في أرقى المناطق",
    "about.services.s2.title": "تأمين المواصلات",
    "about.services.s2.desc": "إيجار وشراء السيارات مع سائقين محترفين",
    "about.services.s3.title": "خدمات مصاحبة",
    "about.services.s3.desc": "خدمات VIP ومتابعة شخصية لرجال الأعمال",
    "about.stats.clients": "عميل سعيد",
    "about.stats.years": "سنوات خبرة",
    "about.stats.listings": "عقار وسيارة",
    "about.stats.langs": "لغة للتعامل",
    "about.testimonials.title": "آراء عملائنا",
    "contact.title": "تواصل معنا",
    "contact.subtitle": "فريقنا جاهز للرد على استفساراتك خلال دقائق",
    "contact.form.name": "الاسم",
    "contact.form.phone": "رقم الهاتف",
    "contact.form.service": "نوع الخدمة",
    "contact.form.message": "رسالتك",
    "contact.form.service.apartment_rent": "إيجار شقة",
    "contact.form.service.apartment_sale": "شراء شقة",
    "contact.form.service.car_rent": "إيجار سيارة",
    "contact.form.service.car_sale": "شراء سيارة",
    "contact.form.service.other": "أخرى",
    "contact.form.placeholder.name": "اكتب اسمك الكامل",
    "contact.form.placeholder.phone": "01xxxxxxxxx",
    "contact.form.placeholder.message": "اكتب تفاصيل طلبك هنا...",
    "contact.form.submit": "إرسال عبر واتساب",
    "contact.form.error.name": "من فضلك اكتب اسمك",
    "contact.form.error.phone": "من فضلك اكتب رقم هاتف صحيح",
    "contact.info.title": "معلومات التواصل",
    "contact.info.whatsapp": "واتساب",
    "contact.info.phone": "هاتف",
    "contact.info.email": "بريد إلكتروني",
    "contact.info.address": "العنوان",
    "contact.info.hours": "ساعات العمل",
    "contact.info.hoursValue": "السبت - الخميس: 9 ص - 9 م",
    "footer.tagline": "خدمات رجال الأعمال الشاملة بمصر",
    "footer.quicklinks": "روابط سريعة",
    "footer.contact": "تواصل",
    "footer.follow": "تابعنا",
    "footer.rights": "جميع الحقوق محفوظة",
    "admin.title": "لوحة التحكم",
    "admin.login": "تسجيل الدخول",
    "admin.email": "البريد الإلكتروني",
    "admin.password": "كلمة المرور",
    "admin.signIn": "دخول",
    "admin.signOut": "خروج",
    "admin.add": "إضافة عنصر",
    "admin.edit": "تعديل",
    "admin.delete": "حذف",
    "admin.save": "حفظ",
    "admin.cancel": "إلغاء",
    "admin.confirmDelete": "هل أنت متأكد من حذف هذا العنصر؟",
    "admin.listings": "العناصر",
    "admin.empty": "لا توجد عناصر بعد. ابدأ بإضافة أول عنصر.",
    "admin.authError": "بيانات الدخول غير صحيحة. حاول مرة أخرى.",
    "admin.loading": "جاري التحميل...",
    "admin.backHome": "العودة للموقع",
    "lang.toggle": "English",
    "common.loading": "جاري التحميل...",
    "common.error": "حدث خطأ. حاول مرة أخرى.",
  },
  en: {
    "nav.home": "Home",
    "nav.apartment_rent": "Apartments for Rent",
    "nav.apartment_sale": "Apartments for Sale",
    "nav.car_rent": "Cars for Rent",
    "nav.car_sale": "Cars for Sale",
    "nav.about": "About",
    "nav.contact": "Contact",
    "nav.admin": "Admin",
    "cta.inquire": "Inquire on WhatsApp",
    "cta.contact": "Contact Us",
    "cta.viewAll": "View All",
    "cta.details": "Details",
    "cta.close": "Close",
    "cta.explore": "Explore Our Services",
    "cta.getInTouch": "Get Started",
    "hero.badge": "Premier Business Services",
    "hero.title": "Your Trusted Partner for Business in Egypt",
    "hero.subtitle":
      "We provide Egyptian and international business professionals with luxury housing, premium transport, and integrated concierge services to global standards.",
    "hero.cta1": "Browse Apartments",
    "hero.cta2": "Rent a Car",
    "section.apartment_rent.title": "Apartments for Rent",
    "section.apartment_rent.subtitle": "Furnished luxury apartments in the finest districts",
    "section.apartment_sale.title": "Apartments for Sale",
    "section.apartment_sale.subtitle": "Curated ownership opportunities in premium compounds",
    "section.car_rent.title": "Cars for Rent",
    "section.car_rent.subtitle": "Luxury fleet with professional chauffeurs for every occasion",
    "section.car_sale.title": "Cars for Sale",
    "section.car_sale.subtitle": "Agency-condition vehicles with certified warranty",
    "filter.all": "All",
    "filter.region": "Region",
    "filter.sort": "Sort",
    "filter.sort.newest": "Newest",
    "filter.sort.priceLow": "Price: Low to High",
    "filter.sort.priceHigh": "Price: High to Low",
    "filter.results": "results",
    "filter.noResults": "No matching items at the moment.",
    "card.bedrooms": "beds",
    "card.bathrooms": "baths",
    "card.area": "sqm",
    "card.year": "year",
    "card.location": "Location",
    "card.priceOnRequest": "Price on Request",
    "card.perMonth": "/ month",
    "card.perDay": "/ day",
    "card.unavailable": "Unavailable",
    "card.available": "Available",
    "about.title": "About Us",
    "about.kicker": "Al Rayan Group",
    "about.lead":
      "Al Rayan Group is a specialized provider of comprehensive business services for Egyptian and international clients, combining local expertise with global standards for a seamless, trusted experience.",
    "about.p1":
      "We started with a simple vision: business professionals visiting or residing in Egypt should focus on their work while we handle their housing, transport, and every supporting service they need.",
    "about.p2":
      "We operate in both Arabic and English and obsess over the smallest details to guarantee our clients comfort, privacy, and credibility at the highest level.",
    "about.services.title": "Our Services",
    "about.services.s1.title": "Housing",
    "about.services.s1.desc": "Rent and sale of luxury apartments in prime areas",
    "about.services.s2.title": "Transport",
    "about.services.s2.desc": "Rent and purchase of cars with professional chauffeurs",
    "about.services.s3.title": "Concierge",
    "about.services.s3.desc": "VIP and personal assistance for business clients",
    "about.stats.clients": "Happy Clients",
    "about.stats.years": "Years of Experience",
    "about.stats.listings": "Listings",
    "about.stats.langs": "Languages Served",
    "about.testimonials.title": "Client Testimonials",
    "contact.title": "Contact Us",
    "contact.subtitle": "Our team is ready to answer your inquiries within minutes",
    "contact.form.name": "Name",
    "contact.form.phone": "Phone Number",
    "contact.form.service": "Service Type",
    "contact.form.message": "Your Message",
    "contact.form.service.apartment_rent": "Apartment for Rent",
    "contact.form.service.apartment_sale": "Apartment for Sale",
    "contact.form.service.car_rent": "Car for Rent",
    "contact.form.service.car_sale": "Car for Sale",
    "contact.form.service.other": "Other",
    "contact.form.placeholder.name": "Enter your full name",
    "contact.form.placeholder.phone": "01xxxxxxxxx",
    "contact.form.placeholder.message": "Type the details of your request here...",
    "contact.form.submit": "Send via WhatsApp",
    "contact.form.error.name": "Please enter your name",
    "contact.form.error.phone": "Please enter a valid phone number",
    "contact.info.title": "Contact Information",
    "contact.info.whatsapp": "WhatsApp",
    "contact.info.phone": "Phone",
    "contact.info.email": "Email",
    "contact.info.address": "Address",
    "contact.info.hours": "Working Hours",
    "contact.info.hoursValue": "Sat – Thu: 9 AM – 9 PM",
    "footer.tagline": "Comprehensive business services in Egypt",
    "footer.quicklinks": "Quick Links",
    "footer.contact": "Contact",
    "footer.follow": "Follow Us",
    "footer.rights": "All rights reserved",
    "admin.title": "Admin Panel",
    "admin.login": "Sign In",
    "admin.email": "Email",
    "admin.password": "Password",
    "admin.signIn": "Sign In",
    "admin.signOut": "Sign Out",
    "admin.add": "Add Listing",
    "admin.edit": "Edit",
    "admin.delete": "Delete",
    "admin.save": "Save",
    "admin.cancel": "Cancel",
    "admin.confirmDelete": "Are you sure you want to delete this listing?",
    "admin.listings": "Listings",
    "admin.empty": "No listings yet. Add your first one.",
    "admin.authError": "Invalid credentials. Please try again.",
    "admin.loading": "Loading...",
    "admin.backHome": "Back to site",
    "lang.toggle": "العربية",
    "common.loading": "Loading...",
    "common.error": "An error occurred. Please try again.",
  },
};

const I18nContext = createContext<I18nContextValue | null>(null);

const STORAGE_KEY = "arg-lang";

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(() => {
    const saved = localStorage.getItem(STORAGE_KEY) as Lang | null;
    return saved === "en" || saved === "ar" ? saved : "ar";
  });

  const dir: "rtl" | "ltr" = lang === "ar" ? "rtl" : "ltr";

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = dir;
    localStorage.setItem(STORAGE_KEY, lang);
  }, [lang, dir]);

  const setLang = (l: Lang) => setLangState(l);
  const toggle = () => setLangState((p) => (p === "ar" ? "en" : "ar"));
  const t = (key: string) => dict[lang][key] ?? key;
  const pick = <T,>(ar: T, en: T): T => (lang === "ar" ? ar : en);

  return (
    <I18nContext.Provider value={{ lang, dir, setLang, toggle, t, pick }}>
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n() {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error("useI18n must be used within I18nProvider");
  return ctx;
}
