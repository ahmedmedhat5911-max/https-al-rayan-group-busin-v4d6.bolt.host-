import { useEffect, useState } from "react";
import { supabase } from "../lib/supabase";
import type { Listing, ListingCategory } from "../types";

export function useListings(category: ListingCategory | null) {
  const [listings, setListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError(null);

    const q = supabase
      .from("listings")
      .select("*")
      .order("sort_order", { ascending: false })
      .order("created_at", { ascending: false });

    if (category) q.eq("category", category);

    q.then(({ data, error: err }) => {
      if (!active) return;
      if (err) {
        setError(err.message);
        setListings([]);
      } else {
        setListings((data as Listing[]) ?? []);
      }
      setLoading(false);
    });

    return () => {
      active = false;
    };
  }, [category]);

  return { listings, loading, error };
}

export function useFeaturedListings() {
  const [listings, setListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    supabase
      .from("listings")
      .select("*")
      .eq("featured", true)
      .eq("available", true)
      .order("sort_order", { ascending: false })
      .order("created_at", { ascending: false })
      .then(({ data, error }) => {
        if (!active) return;
        if (!error && data) setListings(data as Listing[]);
        setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  return { listings, loading };
}
