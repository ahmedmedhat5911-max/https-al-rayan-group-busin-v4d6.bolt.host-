import { COMPANY } from "../lib/company";
import { useI18n } from "../i18n";
import { WhatsAppIcon } from "./whatsapp";

export function FloatingWhatsApp() {
  const { lang } = useI18n();
  const msg = lang === "ar"
    ? "مرحبًا الريان جروب، أرغب في الاستفسار عن خدماتكم."
    : "Hello Al Rayan Group, I would like to inquire about your services.";
  const href = `https://wa.me/${COMPANY.whatsapp}?text=${encodeURIComponent(msg)}`;

  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="WhatsApp"
      className="group fixed bottom-5 end-5 z-50 flex items-center gap-3 rounded-full bg-[#25D366] p-3.5 text-white shadow-[0_10px_30px_-5px_rgba(37,211,102,0.5)] transition-all duration-500 ease-luxury hover:scale-105 hover:shadow-[0_14px_40px_-5px_rgba(37,211,102,0.65)] sm:bottom-7 sm:end-7"
    >
      <span className="absolute inset-0 animate-ping rounded-full bg-[#25D366] opacity-30 group-hover:opacity-0" />
      <WhatsAppIcon className="relative h-7 w-7" />
      <span className="relative hidden text-sm font-semibold sm:inline">
        {lang === "ar" ? "تواصل واتساب" : "Chat on WhatsApp"}
      </span>
    </a>
  );
}
