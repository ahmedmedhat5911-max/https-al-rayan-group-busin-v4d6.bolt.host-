import { useI18n } from "../i18n";
import { COMPANY } from "../lib/company";

export function Logo({ className = "", onClick }: { className?: string; onClick?: () => void }) {
  const { lang } = useI18n();
  return (
    <button
      onClick={onClick}
      className={`group flex items-center gap-3 ${className}`}
      aria-label={COMPANY.name_en}
    >
      <span className="relative grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-ink-800 to-ink-950 ring-1 ring-gold-400/30 transition-transform duration-500 ease-luxury group-hover:scale-105">
        <svg viewBox="0 0 64 64" className="h-7 w-7" fill="none" aria-hidden>
          <path
            d="M20 16h10c7 0 12 4 12 11s-5 11-12 11H20zM30 24v14M30 38h8"
            stroke="#d4ad42"
            strokeWidth="3.4"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
        <span className="pointer-events-none absolute inset-0 rounded-xl ring-1 ring-gold-400/0 transition-all duration-500 group-hover:ring-gold-400/40" />
      </span>
      <span className="flex flex-col items-start leading-none">
        <span className="font-display text-lg font-bold tracking-wide text-ink-50">
          {lang === "ar" ? COMPANY.name_ar : COMPANY.name_en}
        </span>
        <span className="mt-0.5 text-[10px] font-medium uppercase tracking-[0.28em] text-gold-300">
          {lang === "ar" ? COMPANY.name_en : COMPANY.name_ar}
        </span>
      </span>
    </button>
  );
}
