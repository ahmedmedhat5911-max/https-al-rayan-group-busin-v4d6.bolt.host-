import { useEffect, useState } from "react";
import { useI18n } from "../i18n";
import type { Listing } from "../types";
import { WhatsAppIcon, buildInquiryMessage } from "./whatsapp";
import { whatsappLink, COMPANY } from "../lib/company";

export function ListingModal({
  listing,
  onClose,
}: {
  listing: Listing | null;
  onClose: () => void;
}) {
  const { t, lang, pick } = useI18n();
  const [idx, setIdx] = useState(0);

  useEffect(() => {
    setIdx(0);
  }, [listing?.id]);

  useEffect(() => {
    if (!listing) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") setIdx((p) => (p + 1) % listing.images.length);
      if (e.key === "ArrowLeft") setIdx((p) => (p - 1 + listing.images.length) % listing.images.length);
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [listing, onClose]);

  if (!listing) return null;

  const isCar = listing.category.startsWith("car_");
  const isRent = listing.category.endsWith("_rent");
  const title = pick(listing.title_ar, listing.title_en);
  const location = pick(listing.location_ar, listing.location_en);
  const desc = pick(listing.desc_ar, listing.desc_en);
  const spec = pick(listing.spec_ar, listing.spec_en);
  const total = listing.images.length;

  const priceLabel = listing.price
    ? new Intl.NumberFormat(lang === "ar" ? "ar-EG" : "en-US").format(listing.price)
    : t("card.priceOnRequest");
  const period = isRent ? (isCar ? t("card.perDay") : t("card.perMonth")) : "";

  const prev = () => setIdx((p) => (p - 1 + total) % total);
  const next = () => setIdx((p) => (p + 1) % total);

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center p-4 sm:p-6"
      role="dialog"
      aria-modal="true"
    >
      <div
        className="absolute inset-0 bg-ink-950/85 backdrop-blur-md animate-fade-in"
        onClick={onClose}
      />

      <div className="relative z-10 w-full max-w-4xl animate-fade-up overflow-hidden rounded-2xl border border-ink-600/40 bg-ink-900 shadow-luxury">
        {/* Gallery */}
        <div className="relative aspect-[16/10] overflow-hidden bg-ink-800">
          {total > 0 ? (
            <img
              src={listing.images[idx]}
              alt={title}
              className="h-full w-full object-cover"
            />
          ) : (
            <div className="h-full w-full" />
          )}

          {total > 1 && (
            <>
              <button
                onClick={prev}
                className="absolute start-3 top-1/2 grid h-10 w-10 -translate-y-1/2 place-items-center rounded-full bg-ink-950/60 text-white transition-colors hover:bg-gold-400 hover:text-ink-950"
                aria-label="Previous"
              >
                <Chevron dir="left" />
              </button>
              <button
                onClick={next}
                className="absolute end-3 top-1/2 grid h-10 w-10 -translate-y-1/2 place-items-center rounded-full bg-ink-950/60 text-white transition-colors hover:bg-gold-400 hover:text-ink-950"
                aria-label="Next"
              >
                <Chevron dir="right" />
              </button>

              <div className="absolute bottom-3 start-1/2 flex -translate-x-1/2 gap-1.5 rtl:translate-x-1/2">
                {listing.images.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setIdx(i)}
                    className={`h-1.5 rounded-full transition-all ${
                      i === idx ? "w-6 bg-gold-400" : "w-1.5 bg-white/50"
                    }`}
                    aria-label={`Image ${i + 1}`}
                  />
                ))}
              </div>
            </>
          )}

          <button
            onClick={onClose}
            className="absolute end-3 top-3 grid h-9 w-9 place-items-center rounded-full bg-ink-950/60 text-white transition-colors hover:bg-ink-700"
            aria-label={t("cta.close")}
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M18 6L6 18M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Details */}
        <div className="max-h-[45vh] overflow-y-auto p-6 sm:p-8">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <h2 className="font-display text-2xl font-bold text-ink-50">{title}</h2>
              {location && (
                <p className="mt-1.5 flex items-center gap-1.5 text-sm text-ink-300">
                  <PinIcon /> {location}
                </p>
              )}
            </div>
            <div className="text-end">
              <div className="font-display text-2xl font-bold gold-text">
                {priceLabel}
                {listing.price && period && (
                  <span className="ms-1 text-xs font-medium text-ink-300">{period}</span>
                )}
              </div>
              {!listing.available && (
                <span className="mt-1 inline-block rounded-full bg-ink-700 px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-ink-200">
                  {t("card.unavailable")}
                </span>
              )}
            </div>
          </div>

          <p className="mt-5 leading-relaxed text-ink-200">{desc}</p>

          {/* specs grid */}
          <dl className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3">
            {!isCar && listing.bedrooms != null && <SpecBox label={t("card.bedrooms")} value={String(listing.bedrooms)} />}
            {!isCar && listing.bathrooms != null && <SpecBox label={t("card.bathrooms")} value={String(listing.bathrooms)} />}
            {!isCar && listing.area_sqm != null && <SpecBox label={t("card.area")} value={String(listing.area_sqm)} />}
            {isCar && listing.make && <SpecBox label={lang === "ar" ? "الماركة" : "Make"} value={listing.make} />}
            {isCar && listing.model && <SpecBox label={lang === "ar" ? "الموديل" : "Model"} value={listing.model} />}
            {isCar && listing.year != null && <SpecBox label={lang === "ar" ? "سنة" : "Year"} value={String(listing.year)} />}
            {spec && <SpecBox label={lang === "ar" ? "المواصفات" : "Spec"} value={spec} />}
          </dl>

          <div className="mt-7 flex flex-col gap-3 sm:flex-row">
            <a
              href={whatsappLink(buildInquiryMessage(listing, lang))}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-gold flex-1"
            >
              <WhatsAppIcon className="h-5 w-5" /> {t("cta.inquire")}
            </a>
            <a
              href={`tel:${COMPANY.phoneIntl}`}
              className="btn-ghost flex-1"
            >
              {t("contact.info.phone")}: {COMPANY.phoneDisplay}
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

function SpecBox({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-ink-600/40 bg-ink-800/40 p-3">
      <dt className="text-[10px] font-semibold uppercase tracking-wider text-gold-300">{label}</dt>
      <dd className="mt-1 text-sm font-medium text-ink-100">{value}</dd>
    </div>
  );
}

function Chevron({ dir }: { dir: "left" | "right" }) {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2.2">
      {dir === "left" ? <path d="M15 18l-6-6 6-6" /> : <path d="M9 18l6-6-6-6" />}
    </svg>
  );
}
function PinIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="1.8">
      <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z" />
      <circle cx="12" cy="10" r="3" />
    </svg>
  );
}
