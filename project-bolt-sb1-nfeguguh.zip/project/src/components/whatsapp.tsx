import { COMPANY } from "../lib/company";
import { useI18n } from "../i18n";
import type { Listing } from "../types";

const categoryLabels: Record<string, { ar: string; en: string }> = {
  apartment_rent: { ar: "إيجار شقة", en: "Apartment for Rent" },
  apartment_sale: { ar: "شراء شقة", en: "Apartment for Sale" },
  car_rent: { ar: "إيجار سيارة", en: "Car for Rent" },
  car_sale: { ar: "شراء سيارة", en: "Car for Sale" },
};

export function buildInquiryMessage(listing: Listing, lang: "ar" | "en"): string {
  const cat = categoryLabels[listing.category];
  const itemLabel = lang === "ar" ? listing.title_ar : listing.title_en;
  const catLabel = lang === "ar" ? cat.ar : cat.en;

  if (lang === "ar") {
    return `مرحبًا، أنا مهتم بـ "${itemLabel}" (${catLabel}) وأرغب في معرفة التفاصيل والتواصل مع فريقكم. من الريان جروب.`;
  }
  return `Hello, I am interested in "${itemLabel}" (${catLabel}) and would like to know the details and connect with your team. — Al Rayan Group.`;
}

export function buildContactMessage({
  name,
  phone,
  service,
  message,
  lang,
}: {
  name: string;
  phone: string;
  service: string;
  message: string;
  lang: "ar" | "en";
}): string {
  const serviceMap: Record<string, { ar: string; en: string }> = {
    apartment_rent: { ar: "إيجار شقة", en: "Apartment for Rent" },
    apartment_sale: { ar: "شراء شقة", en: "Apartment for Sale" },
    car_rent: { ar: "إيجار سيارة", en: "Car for Rent" },
    car_sale: { ar: "شراء سيارة", en: "Car for Sale" },
    other: { ar: "أخرى", en: "Other" },
  };
  const s = serviceMap[service] ?? serviceMap.other;
  const serviceLabel = lang === "ar" ? s.ar : s.en;

  if (lang === "ar") {
    return [
      `مرحبًا، أرغب في التواصل مع الريان جروب.`,
      ``,
      `الاسم: ${name}`,
      `رقم الهاتف: ${phone}`,
      `نوع الخدمة: ${serviceLabel}`,
      message ? `الرسالة: ${message}` : null,
    ]
      .filter(Boolean)
      .join("\n");
  }
  return [
    `Hello, I would like to get in touch with Al Rayan Group.`,
    ``,
    `Name: ${name}`,
    `Phone: ${phone}`,
    `Service: ${serviceLabel}`,
    message ? `Message: ${message}` : null,
  ]
    .filter(Boolean)
    .join("\n");
}

export function WhatsAppIcon({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden>
      <path d="M.057 24l1.687-6.163a11.867 11.867 0 01-1.587-5.946C.16 5.335 5.495 0 12.05 0a11.821 11.821 0 018.413 3.488 11.824 11.824 0 013.48 8.414c-.003 6.557-5.338 11.892-11.893 11.892a11.9 11.9 0 01-5.688-1.448L.057 24zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884a9.86 9.86 0 001.51 5.26l-.999 3.648 3.978-.607zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.71.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.247-.694.247-1.289.173-1.413z" />
    </svg>
  );
}

export { COMPANY };
