import { useEffect, useState } from "react";
import { NavLink, Link, useLocation } from "react-router-dom";
import { useI18n } from "../i18n";
import type { ListingCategory } from "../types";
import { Logo } from "./Logo";

const routes: { to: string; key: string }[] = [
  { to: "/", key: "nav.home" },
  { to: "/listings/apartment_rent", key: "nav.apartment_rent" },
  { to: "/listings/apartment_sale", key: "nav.apartment_sale" },
  { to: "/listings/car_rent", key: "nav.car_rent" },
  { to: "/listings/car_sale", key: "nav.car_sale" },
  { to: "/about", key: "nav.about" },
  { to: "/contact", key: "nav.contact" },
];

export function Navbar() {
  const { t, lang, toggle } = useI18n();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-40 transition-all duration-500 ease-luxury ${
        scrolled
          ? "border-b border-ink-600/40 bg-ink-950/90 backdrop-blur-xl"
          : "border-b border-transparent bg-gradient-to-b from-ink-950/70 to-transparent"
      }`}
    >
      <nav className="container-lux flex h-20 items-center justify-between gap-4">
        <Logo onClick={() => setOpen(false)} />

        {/* Desktop nav */}
        <ul className="hidden items-center gap-7 xl:flex">
          {routes.map((r) => (
            <li key={r.to}>
              <NavLink
                to={r.to}
                end={r.to === "/"}
                className={({ isActive }) => `nav-link ${isActive ? "active" : ""}`}
              >
                {t(r.key)}
              </NavLink>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-2">
          <button
            onClick={toggle}
            className="flex items-center gap-1.5 rounded-full border border-ink-500/50 px-3 py-2 text-xs font-semibold text-ink-100 transition-colors hover:border-gold-400/60 hover:text-gold-300"
            aria-label="Switch language"
          >
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.8">
              <circle cx="12" cy="12" r="9" />
              <path d="M3 12h18M12 3a14 14 0 010 18M12 3a14 14 0 000 18" />
            </svg>
            {t("lang.toggle")}
          </button>

          <Link to="/contact" className="hidden btn-gold !px-5 !py-2.5 lg:inline-flex">
            {t("cta.getInTouch")}
          </Link>

          {/* Mobile menu toggle */}
          <button
            onClick={() => setOpen((p) => !p)}
            className="grid h-10 w-10 place-items-center rounded-lg border border-ink-600/40 text-ink-100 xl:hidden"
            aria-label="Menu"
            aria-expanded={open}
          >
            <span className="relative block h-4 w-5">
              <span className={`absolute left-0 h-0.5 w-5 bg-current transition-all duration-300 ${open ? "top-2 rotate-45" : "top-0"}`} />
              <span className={`absolute left-0 top-2 h-0.5 w-5 bg-current transition-all duration-300 ${open ? "opacity-0" : "opacity-100"}`} />
              <span className={`absolute left-0 h-0.5 w-5 bg-current transition-all duration-300 ${open ? "top-2 -rotate-45" : "top-4"}`} />
            </span>
          </button>
        </div>
      </nav>

      {/* Mobile drawer */}
      <div
        className={`xl:hidden ${open ? "pointer-events-auto" : "pointer-events-none"}`}
        aria-hidden={!open}
      >
        <div
          className={`fixed inset-0 top-20 bg-ink-950/80 backdrop-blur-sm transition-opacity duration-300 ${
            open ? "opacity-100" : "opacity-0"
          }`}
          onClick={() => setOpen(false)}
        />
        <div
          className={`absolute inset-x-0 top-20 origin-top border-b border-ink-600/40 bg-ink-900 transition-all duration-400 ease-luxury ${
            open ? "scale-y-100 opacity-100" : "scale-y-95 opacity-0"
          }`}
        >
          <ul className="container-lux flex flex-col gap-1 py-6">
            {routes.map((r) => (
              <li key={r.to}>
                <NavLink
                  to={r.to}
                  end={r.to === "/"}
                  className={({ isActive }) =>
                    `block rounded-xl px-4 py-3.5 text-base font-medium transition-colors ${
                      isActive ? "bg-gold-400/10 text-gold-300" : "text-ink-100 hover:bg-ink-800/60"
                    }`
                  }
                >
                  {t(r.key)}
                </NavLink>
              </li>
            ))}
            <li className="mt-2">
              <Link to="/contact" className="btn-gold w-full">
                {t("cta.getInTouch")}
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </header>
  );
}

export function categoryFromPath(path: string): ListingCategory | null {
  const m = path.match(/\/listings\/(apartment_rent|apartment_sale|car_rent|car_sale)/);
  return (m?.[1] as ListingCategory) ?? null;
}
