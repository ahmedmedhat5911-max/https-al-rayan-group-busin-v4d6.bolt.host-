import { useEffect, useState } from "react";
import { useI18n } from "../i18n";
import type { Listing } from "../types";
import { WhatsAppIcon, buildInquiryMessage } from "./whatsapp";
import { whatsappLink } from "../lib/company";

export function ListingCard({
  listing,
  onOpen,
}: {
  listing: Listing;
  onOpen: (l: Listing) => void;
}) {
  const { t, lang, pick } = useI18n();
  const isCar = listing.category.startsWith("car_");
  const isRent = listing.category.endsWith("_rent");
  const title = pick(listing.title_ar, listing.title_en);
  const location = pick(listing.location_ar, listing.location_en);
  const desc = pick(listing.desc_ar, listing.desc_en);
  const image = listing.images[0];

  const priceLabel = listing.price
    ? new Intl.NumberFormat(lang === "ar" ? "ar-EG" : "en-US").format(listing.price)
    : t("card.priceOnRequest");

  const period = isRent ? (isCar ? t("card.perDay") : t("card.perMonth")) : "";

  return (
    <article className="card-lux group flex flex-col">
      {/* Image */}
      <button
        onClick={() => onOpen(listing)}
        className="relative block aspect-[4/3] overflow-hidden"
        aria-label={title}
      >
        {image ? (
          <img
            src={image}
            alt={title}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-700 ease-luxury group-hover:scale-110"
          />
        ) : (
          <div className="h-full w-full bg-ink-800" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-ink-950/85 via-ink-950/10 to-transparent" />

        {/* badges */}
        <div className="absolute start-3 top-3 flex flex-col gap-2">
          {listing.featured && (
            <span className="rounded-full bg-gold-400/95 px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-ink-950">
              {lang === "ar" ? "مميز" : "Featured"}
            </span>
          )}
          {!listing.available && (
            <span className="rounded-full bg-ink-700/95 px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-ink-200">
              {t("card.unavailable")}
            </span>
          )}
        </div>

        {/* price */}
        <div className="absolute bottom-3 start-3 end-3 flex items-end justify-between gap-2">
          <div>
            <span className="block font-display text-xl font-bold text-white drop-shadow">
              {priceLabel}
              {listing.price && period && (
                <span className="ms-1 text-xs font-medium text-ink-200">{period}</span>
              )}
            </span>
            {location && (
              <span className="mt-0.5 flex items-center gap-1 text-xs text-ink-200">
                <PinIcon /> {location}
              </span>
            )}
          </div>
        </div>
      </button>

      {/* Body */}
      <div className="flex flex-1 flex-col p-5">
        <h3 className="font-display text-lg font-semibold text-ink-50">{title}</h3>
        <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-ink-300">{desc}</p>

        {/* specs */}
        <div className="mt-4 flex flex-wrap gap-x-4 gap-y-2 text-xs text-ink-300">
          {!isCar && listing.bedrooms != null && (
            <Spec icon={<BedIcon />} label={`${listing.bedrooms} ${t("card.bedrooms")}`} />
          )}
          {!isCar && listing.bathrooms != null && (
            <Spec icon={<BathIcon />} label={`${listing.bathrooms} ${t("card.bathrooms")}`} />
          )}
          {!isCar && listing.area_sqm != null && (
            <Spec icon={<AreaIcon />} label={`${listing.area_sqm} ${t("card.area")}`} />
          )}
          {isCar && listing.make && (
            <Spec icon={<CarIcon />} label={`${listing.make} ${listing.model ?? ""}`.trim()} />
          )}
          {isCar && listing.year != null && (
            <Spec icon={<CalIcon />} label={`${listing.year} ${t("card.year")}`} />
          )}
        </div>

        {/* actions */}
        <div className="mt-5 flex items-center gap-2 pt-1">
          <a
            href={whatsappLink(buildInquiryMessage(listing, lang))}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-gold flex-1 !px-4 !py-2.5 !text-xs"
          >
            <WhatsAppIcon className="h-4 w-4" /> {t("cta.inquire")}
          </a>
          <button
            onClick={() => onOpen(listing)}
            className="btn-ghost !px-4 !py-2.5 !text-xs"
          >
            {t("cta.details")}
          </button>
        </div>
      </div>
    </article>
  );
}

function Spec({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span className="text-gold-400">{icon}</span>
      {label}
    </span>
  );
}

function PinIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="1.8">
      <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z" />
      <circle cx="12" cy="10" r="3" />
    </svg>
  );
}
function BedIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.6">
      <path d="M2 17v-5a2 2 0 012-2h16a2 2 0 012 2v5M2 17h20M6 10V7a2 2 0 012-2h8a2 2 0 012 2v3" />
    </svg>
  );
}
function BathIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.6">
      <path d="M4 12V5a2 2 0 012-2 2 2 0 012 2v1M2 12h20v3a4 4 0 01-4 4H6a4 4 0 01-4-4v-3zM6 19l-1 2M18 19l1 2" />
    </svg>
  );
}
function AreaIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.6">
      <rect x="3" y="3" width="18" height="18" rx="2" />
      <path d="M3 9h18M9 3v18" />
    </svg>
  );
}
function CarIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.6">
      <path d="M5 17h14l-1.5-6a2 2 0 00-2-1.5h-7a2 2 0 00-2 1.5L5 17z" />
      <circle cx="7.5" cy="17.5" r="1.5" />
      <circle cx="16.5" cy="17.5" r="1.5" />
    </svg>
  );
}
function CalIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.6">
      <rect x="3" y="4" width="18" height="18" rx="2" />
      <path d="M3 10h18M8 2v4M16 2v4" />
    </svg>
  );
}

export { buildInquiryMessage };
