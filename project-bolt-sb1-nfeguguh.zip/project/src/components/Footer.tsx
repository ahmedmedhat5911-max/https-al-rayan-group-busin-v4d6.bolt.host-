import { Link } from "react-router-dom";
import { useI18n } from "../i18n";
import { COMPANY } from "../lib/company";
import { Logo } from "./Logo";

const quickLinks = [
  { to: "/", key: "nav.home" },
  { to: "/listings/apartment_rent", key: "nav.apartment_rent" },
  { to: "/listings/apartment_sale", key: "nav.apartment_sale" },
  { to: "/listings/car_rent", key: "nav.car_rent" },
  { to: "/listings/car_sale", key: "nav.car_sale" },
  { to: "/about", key: "nav.about" },
];

const socialIcons = [
  { name: "facebook", href: COMPANY.social.facebook, path: "M22 12a10 10 0 10-11.56 9.88v-6.99H7.9V12h2.54V9.8c0-2.5 1.49-3.89 3.78-3.89 1.09 0 2.24.2 2.24.2v2.46h-1.26c-1.24 0-1.63.77-1.63 1.56V12h2.78l-.44 2.89h-2.34v6.99A10 10 0 0022 12z" },
  { name: "instagram", href: COMPANY.social.instagram, path: "M12 2.16c3.2 0 3.58.01 4.85.07 1.17.05 1.8.25 2.23.41.56.22.96.48 1.38.9.42.42.68.82.9 1.38.16.42.36 1.06.41 2.23.06 1.27.07 1.65.07 4.85s-.01 3.58-.07 4.85c-.05 1.17-.25 1.8-.41 2.23-.22.56-.48.96-.9 1.38-.42.42-.82.68-1.38.9-.42.16-1.06.36-2.23.41-1.27.06-1.65.07-4.85.07s-3.58-.01-4.85-.07c-1.17-.05-1.8-.25-2.23-.41a3.7 3.7 0 01-1.38-.9 3.7 3.7 0 01-.9-1.38c-.16-.42-.36-1.06-.41-2.23C2.17 15.58 2.16 15.2 2.16 12s.01-3.58.07-4.85c.05-1.17.25-1.8.41-2.23.22-.56.48-.96.9-1.38.42-.42.82-.68 1.38-.9.42-.16 1.06-.36 2.23-.41C8.42 2.17 8.8 2.16 12 2.16zm0 1.8c-3.15 0-3.5.01-4.74.07-.9.04-1.39.19-1.71.32-.43.17-.74.37-1.06.69-.32.32-.52.63-.69 1.06-.13.32-.28.81-.32 1.71-.06 1.24-.07 1.59-.07 4.74s.01 3.5.07 4.74c.04.9.19 1.39.32 1.71.17.43.37.74.69 1.06.32.32.63.52 1.06.69.32.13.81.28 1.71.32 1.24.06 1.59.07 4.74.07s3.5-.01 4.74-.07c.9-.04 1.39-.19 1.71-.32.43-.17.74-.37 1.06-.69.32-.32.52-.63.69-1.06.13-.32.28-.81.32-1.71.06-1.24.07-1.59.07-4.74s-.01-3.5-.07-4.74c-.04-.9-.19-1.39-.32-1.71a2.85 2.85 0 00-.69-1.06 2.85 2.85 0 00-1.06-.69c-.32-.13-.81-.28-1.71-.32-1.24-.06-1.59-.07-4.74-.07zm0 3.06a5.98 5.98 0 110 11.96 5.98 5.98 0 010-11.96zm0 1.87a4.11 4.11 0 100 8.22 4.11 4.11 0 000-8.22zm6.2-.24a1.4 1.4 0 11-2.8 0 1.4 1.4 0 012.8 0z" },
  { name: "linkedin", href: COMPANY.social.linkedin, path: "M4.98 3.5a2.5 2.5 0 11-.02 5 2.5 2.5 0 01.02-5zM3 8.98h4v12H3v-12zm7 0h3.83v1.64h.05c.53-1 1.84-2.05 3.79-2.05 4.05 0 4.8 2.67 4.8 6.14v6.27h-4v-5.56c0-1.33-.02-3.04-1.85-3.04-1.85 0-2.14 1.45-2.14 2.94v5.66H10v-12z" },
];

export function Footer() {
  const { t, lang } = useI18n();
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-ink-600/40 bg-ink-950">
      <div className="container-lux py-16">
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div className="lg:col-span-1">
            <Logo />
            <p className="mt-5 max-w-xs text-sm leading-relaxed text-ink-300">
              {t("footer.tagline")} — {COMPANY.name_en}
            </p>
            <div className="mt-6 flex gap-3">
              {socialIcons.map((s) => (
                <a
                  key={s.name}
                  href={s.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={s.name}
                  className="grid h-10 w-10 place-items-center rounded-full border border-ink-600/50 text-ink-300 transition-all duration-300 hover:border-gold-400/60 hover:text-gold-300"
                >
                  <svg viewBox="0 0 24 24" className="h-4.5 w-4.5" fill="currentColor">
                    <path d={s.path} />
                  </svg>
                </a>
              ))}
            </div>
          </div>

          {/* Quick links */}
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-[0.2em] text-gold-300">
              {t("footer.quicklinks")}
            </h3>
            <ul className="mt-5 space-y-3">
              {quickLinks.map((l) => (
                <li key={l.to}>
                  <Link
                    to={l.to}
                    className="text-sm text-ink-300 transition-colors hover:text-gold-300"
                  >
                    {t(l.key)}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-[0.2em] text-gold-300">
              {t("footer.contact")}
            </h3>
            <ul className="mt-5 space-y-3 text-sm text-ink-300">
              <li className="flex items-center gap-3">
                <IconPhone /> {COMPANY.phoneDisplay}
              </li>
              <li className="flex items-center gap-3">
                <IconMail /> {COMPANY.email}
              </li>
              <li className="flex items-start gap-3">
                <IconPin /> <span>{lang === "ar" ? COMPANY.address_ar : COMPANY.address_en}</span>
              </li>
            </ul>
          </div>

          {/* Hours */}
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-[0.2em] text-gold-300">
              {t("contact.info.hours")}
            </h3>
            <p className="mt-5 text-sm text-ink-300">{t("contact.info.hoursValue")}</p>
            <div className="mt-6 rounded-xl border border-gold-400/20 bg-gold-400/5 p-4">
              <p className="text-xs leading-relaxed text-ink-200">
                {lang === "ar"
                  ? "خدمة VIP متاحة على مدار الساعة لعملائنا المميزين."
                  : "VIP support available 24/7 for our distinguished clients."}
              </p>
            </div>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-ink-600/40 pt-6 text-xs text-ink-400 sm:flex-row">
          <p>
            © {year} {COMPANY.name_en}. {t("footer.rights")}.
          </p>
          <Link to="/admin" className="text-ink-500 transition-colors hover:text-gold-300">
            {t("nav.admin")}
          </Link>
        </div>
      </div>
    </footer>
  );
}

function IconPhone() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 text-gold-400" fill="none" stroke="currentColor" strokeWidth="1.7">
      <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72c.13.96.36 1.9.7 2.81a2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.9.34 1.85.57 2.81.7A2 2 0 0122 16.92z" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
function IconMail() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 text-gold-400" fill="none" stroke="currentColor" strokeWidth="1.7">
      <rect x="2" y="4" width="20" height="16" rx="2" />
      <path d="M22 7l-10 6L2 7" />
    </svg>
  );
}
function IconPin() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4 mt-0.5 shrink-0 text-gold-400" fill="none" stroke="currentColor" strokeWidth="1.7">
      <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z" />
      <circle cx="12" cy="10" r="3" />
    </svg>
  );
}
