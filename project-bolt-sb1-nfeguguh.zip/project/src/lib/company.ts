export const COMPANY = {
  name_ar: "الريان جروب",
  name_en: "Al Rayan Group",
  // Placeholder WhatsApp number — replace with the real business number.
  whatsapp: "201000000000",
  phoneDisplay: "+20 100 000 0000",
  phoneIntl: "00201000000000",
  email: "info@alrayangroup.com",
  address_ar: "القاهرة الجديدة، التجمع الخامس، مصر",
  address_en: "New Cairo, Fifth Settlement, Egypt",
  social: {
    facebook: "https://facebook.com",
    instagram: "https://instagram.com",
    linkedin: "https://linkedin.com",
  },
};

export function whatsappLink(message: string): string {
  const text = encodeURIComponent(message);
  return `https://wa.me/${COMPANY.whatsapp}?text=${text}`;
}
