/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: {
          950: "#0a0a0b",
          900: "#111114",
          800: "#18181c",
          700: "#222228",
          600: "#2d2d35",
          500: "#3a3a44",
          400: "#5a5a66",
          300: "#8a8a96",
          200: "#c4c4cc",
          100: "#e6e6ea",
        },
        gold: {
          50: "#fbf7ec",
          100: "#f5eccf",
          200: "#ead79c",
          300: "#dec16b",
          400: "#d4ad42",
          500: "#c29a2e",
          600: "#a07d24",
          700: "#7c6120",
          800: "#5c481c",
          900: "#3f3015",
        },
        navy: {
          900: "#0b1729",
          800: "#11203b",
          700: "#1a2f52",
        },
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
        arabic: ["Cairo", "Tajawal", "system-ui", "sans-serif"],
        display: ["Playfair Display", "Georgia", "serif"],
      },
      boxShadow: {
        luxury: "0 20px 60px -15px rgba(0,0,0,0.6), 0 0 0 1px rgba(210,173,66,0.08)",
        card: "0 10px 30px -12px rgba(0,0,0,0.5)",
        "card-hover": "0 25px 50px -12px rgba(0,0,0,0.65), 0 0 0 1px rgba(210,173,66,0.25)",
      },
      transitionTimingFunction: {
        luxury: "cubic-bezier(0.22, 1, 0.36, 1)",
      },
      keyframes: {
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(24px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        "fade-in": { "0%": { opacity: "0" }, "100%": { opacity: "1" } },
        "slow-zoom": {
          "0%": { transform: "scale(1)" },
          "100%": { transform: "scale(1.12)" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
      },
      animation: {
        "fade-up": "fade-up 0.7s cubic-bezier(0.22,1,0.36,1) both",
        "fade-in": "fade-in 0.6s ease both",
        "slow-zoom": "slow-zoom 20s ease-in-out infinite alternate",
        shimmer: "shimmer 2.5s linear infinite",
      },
    },
  },
  plugins: [],
};
