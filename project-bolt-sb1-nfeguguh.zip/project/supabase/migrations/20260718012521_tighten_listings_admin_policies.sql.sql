/*
# Tighten listings write policies to a designated admin identity

1. Why
- The previous INSERT/UPDATE/DELETE policies on `listings` used `WITH CHECK (true)` / `USING (true)`
  scoped to `authenticated`. That meant ANY signed-in user (not just the intended admin) could
  create, edit, or delete every listing — effectively bypassing row-level security.
- This migration replaces those three policies with ones that additionally require the caller's
  authenticated JWT email to equal a single designated admin email.

2. Designated admin identity
- Email: admin@alrayangroup.com
- The Supabase Auth user created with this exact email (email/password, email confirmation OFF)
  is the only account that can write to `listings`. All other authenticated users are read-only
  just like anon visitors. Change this email by editing the literal below and re-applying.

3. Policy changes
- `admin_insert_listings` (INSERT): WITH CHECK now requires
  `auth.jwt() ->> 'email' = 'admin@alrayangroup.com'`.
- `admin_update_listings` (UPDATE): USING and WITH CHECK now require the same email check.
- `admin_delete_listings` (DELETE): USING now requires the same email check.
- `public_read_listings` (SELECT) is intentionally left unchanged — marketing listings are
  public/shared data readable by anon + authenticated. The USING (true) on SELECT is correct
  and documented as intentionally public; it is NOT a bypass because reads are meant to be open.

4. No data changes
- No columns added, renamed, dropped, or retyped.
- No rows inserted, updated, or deleted.
- Only RLS policy definitions on `listings` change.

5. Important notes
1) Create the admin auth user in Supabase with email `admin@alrayangroup.com` (Auth → Users →
   Add user → set password, email confirmation OFF). Only that user can sign in to /admin and
   write listings. The frontend AdminPage already uses signInWithPassword.
2) This is idempotent: each policy is dropped first, then recreated. Re-running is safe.
3) `auth.jwt() ->> 'email'` reads the email from the access token's claims, which is set at
   sign-in time and is user-immutable (unlike raw_user_meta_data).
*/

-- INSERT: only the designated admin email may insert.
DROP POLICY IF EXISTS "admin_insert_listings" ON listings;
CREATE POLICY "admin_insert_listings"
ON listings FOR INSERT
TO authenticated
WITH CHECK (auth.jwt() ->> 'email' = 'admin@alrayangroup.com');

-- UPDATE: only the designated admin email may update (USING gates which rows can be touched,
-- WITH CHECK gates the resulting row state).
DROP POLICY IF EXISTS "admin_update_listings" ON listings;
CREATE POLICY "admin_update_listings"
ON listings FOR UPDATE
TO authenticated
USING (auth.jwt() ->> 'email' = 'admin@alrayangroup.com')
WITH CHECK (auth.jwt() ->> 'email' = 'admin@alrayangroup.com');

-- DELETE: only the designated admin email may delete.
DROP POLICY IF EXISTS "admin_delete_listings" ON listings;
CREATE POLICY "admin_delete_listings"
ON listings FOR DELETE
TO authenticated
USING (auth.jwt() ->> 'email' = 'admin@alrayangroup.com');
