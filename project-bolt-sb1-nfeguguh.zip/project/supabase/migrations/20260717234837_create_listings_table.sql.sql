/*
# Create listings table for Al Rayan Group (single-tenant, admin-auth for writes)

1. New Tables
- `listings`
  - `id` (uuid, primary key)
  - `category` (text, not null) — apartment_rent | apartment_sale | car_rent | car_sale
  - `title_ar`, `title_en` (text, not null)
  - `desc_ar`, `desc_en` (text)
  - `price` (numeric, nullable — null = price on request)
  - `currency` (text, default 'EGP')
  - `location_ar`, `location_en` (text)
  - `region` (text) — filter key
  - `bedrooms`, `bathrooms` (int) — apartments
  - `area_sqm` (numeric) — apartments
  - `make`, `model` (text) — cars
  - `year` (int) — car year
  - `spec_ar`, `spec_en` (text) — car trim/spec
  - `images` (text[]) — gallery URLs
  - `featured` (boolean, default false)
  - `available` (boolean, default true)
  - `sort_order` (int, default 0)
  - `created_at`, `updated_at` (timestamptz)

2. Indexes on category, featured, region.

3. Security
- RLS enabled.
- Public read (anon + authenticated) — marketing site renders listings.
- Write (insert/update/delete) restricted to authenticated (admin panel only).
*/

CREATE TABLE IF NOT EXISTS listings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category text NOT NULL CHECK (category IN ('apartment_rent','apartment_sale','car_rent','car_sale')),
  title_ar text NOT NULL,
  title_en text NOT NULL,
  desc_ar text,
  desc_en text,
  price numeric,
  currency text NOT NULL DEFAULT 'EGP',
  location_ar text,
  location_en text,
  region text,
  bedrooms int,
  bathrooms int,
  area_sqm numeric,
  make text,
  model text,
  year int,
  spec_ar text,
  spec_en text,
  images text[] NOT NULL DEFAULT '{}',
  featured boolean NOT NULL DEFAULT false,
  available boolean NOT NULL DEFAULT true,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_listings_category ON listings(category);
CREATE INDEX IF NOT EXISTS idx_listings_featured ON listings(featured) WHERE featured = true;
CREATE INDEX IF NOT EXISTS idx_listings_region ON listings(region);

ALTER TABLE listings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_read_listings" ON listings;
CREATE POLICY "public_read_listings"
ON listings FOR SELECT
TO anon, authenticated
USING (true);

DROP POLICY IF EXISTS "admin_insert_listings" ON listings;
CREATE POLICY "admin_insert_listings"
ON listings FOR INSERT
TO authenticated
WITH CHECK (true);

DROP POLICY IF EXISTS "admin_update_listings" ON listings;
CREATE POLICY "admin_update_listings"
ON listings FOR UPDATE
TO authenticated
USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "admin_delete_listings" ON listings;
CREATE POLICY "admin_delete_listings"
ON listings FOR DELETE
TO authenticated
USING (true);

INSERT INTO listings (category, title_ar, title_en, desc_ar, desc_en, price, location_ar, location_en, region, bedrooms, bathrooms, area_sqm, images, featured, sort_order) VALUES
('apartment_rent',
 'شقة فاخرة 3 غرف - التجمع الخامس',
 'Luxury 3-Bedroom Apartment — New Cairo',
 'شقة مفروشة بالكامل بإطلالة بانورامية في قلب التجمع الخامس، قريبة من الجامعة الأمريكية والمحاور الرئيسية.',
 'Fully furnished apartment with panoramic view in the heart of New Cairo, steps from AUC and main axes.',
 85000, 'التجمع الخامس، القاهرة الجديدة', 'New Cairo, Fifth Settlement', 'new_cairo', 3, 3, 220,
 ARRAY['https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg','https://images.pexels.com/photos/1648776/pexels-photo-1648776.jpeg','https://images.pexels.com/photos/2724749/pexels-photo-2724749.jpeg','https://images.pexels.com/photos/1080721/pexels-photo-1080721.jpeg'],
 true, 10),
('apartment_rent',
 'بنتهاوس 4 غرف - المعادي',
 'Penthouse 4BR — Maadi',
 'بنتهاوس راقٍ بمساحة واسعة وروف خاص، تشطيب سوبر لوكس وخدمات أمن 24 ساعة.',
 'Elegant penthouse with private roof, super-luxury finishing and 24/7 security.',
 120000, 'المعادي، القاهرة', 'Maadi, Cairo', 'maadi', 4, 4, 320,
 ARRAY['https://images.pexels.com/photos/271624/pexels-photo-271624.jpeg','https://images.pexels.com/photos/2724749/pexels-photo-2724749.jpeg','https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg'],
 true, 9),
('apartment_rent',
 'شقة 2 غرف - زمالك',
 '2-Bedroom Apartment — Zamalek',
 'شقة أنيقة في زمالك بإطلالة على النيل، قريبة من السفارات والكباريهات.',
 'Chic apartment in Zamalek with Nile view, near embassies and fine dining.',
 60000, 'زمالك، القاهرة', 'Zamalek, Cairo', 'zamalek', 2, 2, 140,
 ARRAY['https://images.pexels.com/photos/1648776/pexels-photo-1648776.jpeg','https://images.pexels.com/photos/271624/pexels-photo-271624.jpeg'],
 false, 8),
('apartment_sale',
 'شقة 180م تمليك - الشيخ زايد',
 '180sqm Apartment for Sale — Sheikh Zayed',
 'شقة 180م بتشطيب راقي في كمبوند محروس، 3 غرف و2 حمام ومنطقة استقبال واسعة.',
 '180sqm elegantly finished apartment in gated compound, 3 beds, 2 baths, grand reception.',
 5200000, 'الشيخ زايد، الجيزة', 'Sheikh Zayed, Giza', 'sheikh_zayed', 3, 2, 180,
 ARRAY['https://images.pexels.com/photos/2724749/pexels-photo-2724749.jpeg','https://images.pexels.com/photos/1080721/pexels-photo-1080721.jpeg','https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg'],
 true, 10),
('apartment_sale',
 'دوبلكس 350م - الساحل الشمالي',
 '350sqm Duplex — North Coast',
 'دوبلكس بإطلالة بحر مباشرة في الساحل الشمالي، تصميم عصري وخصوصية تامة.',
 'Direct sea-view duplex on the North Coast, modern design and full privacy.',
 18000000, 'الساحل الشمالي', 'North Coast', 'north_coast', 4, 4, 350,
 ARRAY['https://images.pexels.com/photos/259962/pexels-photo-259962.jpeg','https://images.pexels.com/photos/2724749/pexels-photo-2724749.jpeg'],
 false, 9);

INSERT INTO listings (category, title_ar, title_en, desc_ar, desc_en, price, location_ar, location_en, region, make, model, year, spec_ar, spec_en, images, featured, sort_order) VALUES
('car_rent',
 'مرسيدس E-Class 2023 للإيجار',
 'Mercedes-Benz E-Class 2023 for Rent',
 'سيارة مرسيدس E-Class موديل 2023 مع سائق محترف، مثالية لرجال الأعمال والوفود.',
 'Mercedes E-Class 2023 with professional chauffeur, ideal for executives and delegations.',
 3500, 'القاهرة، القاهرة الجديدة', 'Cairo, New Cairo', 'new_cairo', 'Mercedes-Benz', 'E-Class', 2023, 'كاملة المواصفات، جلد، بانوراما', 'Full option, leather, panoramic roof',
 ARRAY['https://images.pexels.com/photos/3729464/pexels-photo-3729464.jpeg','https://images.pexels.com/photos/210019/pexels-photo-210019.jpeg'],
 true, 10),
('car_rent',
 'بي إم دبليو X5 2022 للإيجار',
 'BMW X5 2022 for Rent',
 'بي إم دبليو X5 للإيجار اليومي أو الشهري مع سائق، أمان وراحة فاخرة.',
 'BMW X5 for daily or monthly rental with chauffeur, safety and luxury.',
 4200, 'القاهرة', 'Cairo', 'cairo', 'BMW', 'X5', 2022, 'دفع رباعي، شاشة، سنسر', 'AWD, display, sensors',
 ARRAY['https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg','https://images.pexels.com/photos/3729464/pexels-photo-3729464.jpeg'],
 true, 9),
('car_rent',
 'تويوتا كامري 2023 للإيجار',
 'Toyota Camry 2023 for Rent',
 'كامري 2023 اقتصادية وموثوقة مع سائق، مناسبة للاجتماعات والتنقل اليومي.',
 'Camry 2023 — economical and reliable with chauffeur, great for daily commutes.',
 5800, 'القاهرة', 'Cairo', 'cairo', 'Toyota', 'Camry', 2023, 'فل أوبشن', 'Full option',
 ARRAY['https://images.pexels.com/photos/210019/pexels-photo-210019.jpeg'],
 false, 8),
('car_sale',
 'مرسيدس S-Class 2023 للبيع',
 'Mercedes-Benz S-Class 2023 for Sale',
 'مرسيدس S-Class موديل 2023 بحالة الوكالة، كاملة المواصفات وضمان معتمد.',
 'Mercedes S-Class 2023 agency condition, full option with certified warranty.',
 6500000, 'القاهرة', 'Cairo', 'cairo', 'Mercedes-Benz', 'S-Class', 2023, 'كاملة المواصفات', 'Full option',
 ARRAY['https://images.pexels.com/photos/3729464/pexels-photo-3729464.jpeg','https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg'],
 true, 10),
('car_sale',
 'رينج روفر فوغ 2022 للبيع',
 'Range Rover Vogue 2022 for Sale',
 'رينج روفر فوغ 2022 حالة ممتازة، دفع رباعي وتشطيبات جلد فاخرة.',
 'Range Rover Vogue 2022 excellent condition, AWD and premium leather trim.',
 7200000, 'القاهرة الجديدة', 'New Cairo', 'new_cairo', 'Land Rover', 'Range Rover Vogue', 2022, 'ديزل، بانوراما', 'Diesel, panoramic',
 ARRAY['https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg','https://images.pexels.com/photos/3729464/pexels-photo-3729464.jpeg'],
 false, 9);
